#engine v8

/*
   OSC Narrowband Extraction v1.1

   An interactive script that extracts grayscale Ha, OIII, optional Synthetic
   SII, and optional Synthetic Luminosity channels from a one-shot-color (OSC)
   linear image acquired through a dual-band narrowband filter. It provides
   real-time in-dialog previews of all channels and can assemble HOO, SHO, and
   Foraxx (2- and 3-channel) color palettes.

   For best results, remove stars and perform noise reduction before running
   this script. The target image must be linear (unstretched).

   Generated channels (all linear, all LinearFit to Ha):

      Ha   = the red channel ( $T[0] ).

      OIII = a selectable combination of the green and blue channels, then
             LinearFit to Ha. The default "Ha-corrected" mode removes Ha bleed
             before combining, using the Ha and OIII bandpass values to compute
             per-filter coefficients:
                wG = 0.6*(oiiiBp/5) / (0.6*(oiiiBp/5) + 0.4)
                wB = 1 - wG
                bG = 0.05*(haBp/5),  bB = 0.02*(haBp/5)
                max( 0, wG*(G - bG*Ha) + wB*(B - bB*Ha) )
             At the 5 nm defaults this reduces to the classic
                max( 0, 0.6*(G - 0.05*Ha) + 0.4*(B - 0.02*Ha) ).

      SII  = max( 0, Ha - k*( OIII - med(OIII) ) ), then LinearFit to Ha.
             The output window is named "<image>_Synth_SII".

      Lum  = blend*Ha + (1-blend)*OIII, then LinearFit to Ha.
             The output window is named "<image>_Synth_Lum".

      Every generated channel is clamped to a minimum pixel value (MIN_K) and
      displayed zoomed to optimal fit with a linear STF.

   Workflow:

      1. Select the dual-band OSC RGB image. Select the OIII combination mode
         and set the Ha/OIII bandpass values if they differ from 5 nm.

      2. Check Synthetic SII and/or Synthetic Luminosity to enable those
         channels. Adjust their blend sliders as desired.

      3. Click Preview to generate downsampled, screen-stretched previews of
         all selected channels without creating any image windows. The SII
         Amount and Lum Blend sliders update their respective previews live.
         Click Preview again after changing Ha/OIII parameters to refresh.

      4. Select any palette images to create (optional).

      5. Click Extract to create all selected linear channels, build any
         selected palettes, and close the dialog.

   Palettes (optional, non-linear):

      Each palette is built from temporary, statistically-stretched copies of
      the channels it needs; the copies are deleted afterward and the linear
      source channels are left untouched.

      Always available:
         HOO              = R: Ha   G: OIII  B: OIII   (bicolor).
         2-Channel Foraxx = a dynamic Ha/OIII palette (per the Foraxx Palette
                            Utility), with per-channel statistical stretch and
                            curves/selective-saturation finishing.

      Available only when Synthetic SII is selected:
         SHO              = R: SII  G: Ha    B: OIII   (Hubble mapping).
         3-Channel Foraxx = a dynamic Ha/OIII/SII palette, with the same
                            per-channel stretch and Foraxx finishing.

   Copyright (C) 2026 Loran Hughes, WestwoodAstro.net

   Foraxx palette generation pixelmath based on The Coldest Nights website
   https://thecoldestnights.com/2020/06/pixinsight-dynamic-narrowband-combinations-with-pixelmath/
   and Foraxx Palette Utility script, copyright (C) 2024 Paul Hancock

   This program is free software: you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation, version 3 of the License.

   This program is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
   more details.

   You should have received a copy of the GNU General Public License along with
   this program.  If not, see <http://www.gnu.org/licenses/>.

Versions:

	1.1 	Refined the UI; added Synthetic Lum channel; added in-dialog previews
	        for all channels; per-channel statistical stretch for Foraxx palettes.
	1.0		Initial release.
*/


#feature-id    Westwood Astro > OSCNarrowbandExtraction

#feature-info  Interactive OSC Narrowband Extraction with an in-dialog, real-time \
   preview of the synthetic SII channel that updates as the SII amount slider \
   is adjusted. Optional HOO, SHO and Foraxx (2- and 3-channel) palette image \
   creation.<br/>\
   <br/>\
   Copyright &copy; 2026 Loran Hughes, WestwoodAstro.net

#feature-icon  OSCNarrowbandExtraction.svg

#define VERSION "1.1"

#define TITLE   "OSC Narrowband Extraction "

#define PREVIEW_SIZE 360   // target max dimension of the preview rendition, px

#define MIN_K 0.0001       // minimum pixel value (floor) for generated channels

#define PREVIEW_BG 0.25    // STF target background for the live preview
#define PALETTE_BG 0.18    // STF target background for palette copies (darker)


CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/*
 * OIII channel-combination modes.
 */
function oiiiExpression( haBandpass, oiiiBandpass )
{
   // G/B mixing weights: wider OIII bandpass → G more dominant (G sensitivity
   // at OIII λ increases with bandwidth); Ha bleed scales linearly with Ha bandpass.
   var gRaw  = 0.6 * (oiiiBandpass / 5.0);
   var bRaw  = 0.4;
   var total = gRaw + bRaw;
   var wG = format( "%.6f", gRaw / total );
   var wB = format( "%.6f", bRaw / total );
   var bG = format( "%.6f", 0.05 * (haBandpass / 5.0) );
   var bB = format( "%.6f", 0.02 * (haBandpass / 5.0) );
   return "max( 0, " + wG + "*( $T[1] - " + bG + "*$T[0] ) + "
          + wB + "*( $T[2] - " + bB + "*$T[0] ) )";
}

/*
 * SII synthesis: SII = max( 0, Ha - amount*( OIII - med(OIII) ) ).
 */
function siiExpression( amount, haId, oiiiId )
{
   var a = format( "%.6f", amount );
   return "max( 0, " + haId + " - " + a + "*( " + oiiiId + " - med( " + oiiiId + " ) ) )";
}

function lumExpression( amount, haId, oiiiId )
{
   var wHa   = format( "%.6f", amount );
   var wOIII = format( "%.6f", 1.0 - amount );
   return wHa + "*" + haId + " + " + wOIII + "*" + oiiiId;
}

function computeLumInto( view, haId, oiiiId, amount )
{
   var pm = new PixelMath;
   pm.expression          = lumExpression( amount, haId, oiiiId );
   pm.useSingleExpression = true;
   pm.variables           = "";
   pm.use64BitWorkingImage = false;
   pm.rescale             = false;
   pm.truncate            = true;
   pm.truncateLower       = 0.0;
   pm.truncateUpper       = 1.0;
   pm.createNewImage      = false;
   pm.executeOn( view, false/*swapFile*/ );
}

/*
 * Like extractChannel(), but the result window is never shown — it stays
 * hidden and must be closed by the caller. The expression may use $T to
 * refer to the source; $T is substituted with the source view id so PixelMath
 * can resolve it when executed on the separate hidden output window.
 */
function extractChannelHidden( sourceView, expression, newId )
{
   var expr = expression.replace( /\$T/g, sourceView.id );
   var img  = sourceView.image;
   var w = new ImageWindow( img.width, img.height, 1,
                            sourceView.window.bitsPerSample,
                            sourceView.window.isFloatSample,
                            false/*color*/, newId );
   var pm = new PixelMath;
   pm.expression           = expr;
   pm.expression1          = "";
   pm.expression2          = "";
   pm.useSingleExpression  = true;
   pm.variables            = "";
   pm.use64BitWorkingImage = false;
   pm.rescale              = false;
   pm.truncate             = true;
   pm.truncateLower        = 0.0;
   pm.truncateUpper        = 1.0;
   pm.createNewImage       = false;
   pm.executeOn( w.mainView, false/*swapFile*/ );
   return w;
}

/*
 * Creates a new grayscale image window holding the result of a PixelMath
 * expression evaluated on the target view. The new window is returned.
 */
function extractChannel( view, expression, newId )
{
   var pm = new PixelMath;
   pm.expression          = expression;
   pm.expression1         = "";
   pm.expression2         = "";
   pm.useSingleExpression = true;
   pm.variables           = "";
   pm.use64BitWorkingImage = false;
   pm.rescale             = false;
   pm.truncate            = true;
   pm.truncateLower       = 0.0;
   pm.truncateUpper       = 1.0;
   pm.createNewImage      = true;
   pm.newImageId          = newId;
   pm.newImageWidth       = 0;
   pm.newImageHeight      = 0;
   pm.newImageColorSpace  = PixelMath.Gray;
   pm.newImageSampleFormat = PixelMath.SameAsTarget;

   pm.executeOn( view, false/*swapFile*/ );

   return ImageWindow.windowById( newId );
}

/*
 * Recomputes the SII expression into an existing view, in place.
 */
function computeSIIInto( view, haId, oiiiId, amount )
{
   var pm = new PixelMath;
   pm.expression          = siiExpression( amount, haId, oiiiId );
   pm.useSingleExpression = true;
   pm.variables           = "";
   pm.use64BitWorkingImage = false;
   pm.rescale             = false;
   pm.truncate            = true;
   pm.truncateLower       = 0.0;
   pm.truncateUpper       = 1.0;
   pm.createNewImage      = false;
   pm.executeOn( view, false/*swapFile*/ );
}

/*
 * Clamps a view's pixel values to a minimum floor, in place, so no sample is
 * less than the given value: K = max( K, floor ).
 */
function applyFloor( view, floor )
{
   var pm = new PixelMath;
   pm.expression          = "max( $T, " + format( "%.8f", floor ) + " )";
   pm.useSingleExpression = true;
   pm.variables           = "";
   pm.use64BitWorkingImage = false;
   pm.rescale             = false;
   pm.truncate            = true;
   pm.truncateLower       = 0.0;
   pm.truncateUpper       = 1.0;
   pm.createNewImage      = false;
   pm.executeOn( view, false/*swapFile*/ );
}

/*
 * Linearly fits a target view to a reference view (by id).
 */
function linearFitTo( targetView, referenceId )
{
   var lf = new LinearFit;
   lf.referenceViewId = referenceId;
   lf.rejectLow  = 0.0;
   lf.rejectHigh = 0.92;
   lf.executeOn( targetView, false/*swapFile*/ );
}

/*
 * Creates a new RGB image window from three PixelMath channel expressions
 * (R, G, B). The expression strings typically reference grayscale view ids.
 */
function combineRGB( view, exprR, exprG, exprB, newId )
{
   var pm = new PixelMath;
   pm.expression          = exprR;
   pm.expression1         = exprG;
   pm.expression2         = exprB;
   pm.expression3         = "";
   pm.useSingleExpression = false;
   pm.variables           = "";
   pm.use64BitWorkingImage = false;
   pm.rescale             = false;
   pm.truncate            = true;
   pm.truncateLower       = 0.0;
   pm.truncateUpper       = 1.0;
   pm.createNewImage      = true;
   pm.newImageId          = newId;
   pm.newImageColorSpace  = PixelMath.RGB;
   pm.newImageSampleFormat = PixelMath.SameAsTarget;
   pm.executeOn( view, false/*swapFile*/ );
   return ImageWindow.windowById( newId );
}

/*
 * Applies the Foraxx finishing adjustments to a view (curves + selective
 * saturation).
 */
function applyForaxxFinishing( view )
{
   // CurvesAdjustments1
   var c1 = new CurvesTransformation;
   c1.ct = CurvesTransformation.AkimaSubsplines;
   c1.H = [ [ 0.00000, 0.00000 ],
            [ 0.02517, 0.05952 ],
            [ 0.07323, 0.08571 ],
            [ 0.11442, 0.13810 ],
            [ 0.62014, 0.67619 ],
            [ 1.00000, 1.00000 ] ];
   c1.Ht = CurvesTransformation.AkimaSubsplines;
   c1.S = [ [ 0.00000, 0.00000 ],
            [ 0.50801, 0.61667 ],
            [ 1.00000, 1.00000 ] ];
   c1.St = CurvesTransformation.AkimaSubsplines;
   c1.executeOn( view );

   // CurvesAdjustments2
   var c2 = new CurvesTransformation;
   c2.H = [ [ 0.00000, 0.00000 ],
            [ 0.05034, 0.03571 ],
            [ 0.08238, 0.10238 ],
            [ 0.24943, 0.25000 ],
            [ 1.00000, 1.00000 ] ];
   c2.Ht = CurvesTransformation.AkimaSubsplines;
   c2.executeOn( view );

   // SelectiveSaturationBoost, applied twice
   for ( var i = 0; i < 2; ++i )
   {
      var s = new ColorSaturation;
      s.HS = [ [ 0.00000,  0.00000 ],
               [ 0.04910,  0.00909 ],
               [ 0.07235,  0.00909 ],
               [ 0.10594,  0.15455 ],
               [ 0.19380,  0.00909 ],
               [ 0.37726,  0.00000 ],
               [ 0.52972,  0.00909 ],
               [ 0.60465,  0.13636 ],
               [ 0.68475, -0.00909 ],
               [ 0.84496,  0.00000 ],
               [ 1.00000,  0.00000 ] ];
      s.HSt = ColorSaturation.AkimaSubsplines;
      s.hueShift = 0.000;
      s.executeOn( view );
   }
}

/*
 * Sets the shadows (black point) and highlights (white point) so the histogram
 * is expanded to the full [0,1] range WITHOUT clipping any data (midtones left
 * at 0.5).
 *
 * If 'combined' is true, a single black/white point (the global min/max across
 * the RGB channels) is applied to the combined RGB/K channel, which preserves
 * the color balance. Otherwise each RGB channel is set to its own min/max.
 */
function setShadowsHighlights( view, combined )
{
   var image = view.image;
   var n = Math.min( 3, image.numberOfChannels );
   var H = [ [ 0, 0.5, 1, 0, 1 ],   // R
             [ 0, 0.5, 1, 0, 1 ],   // G
             [ 0, 0.5, 1, 0, 1 ],   // B
             [ 0, 0.5, 1, 0, 1 ],   // RGB/K
             [ 0, 0.5, 1, 0, 1 ] ]; // Alpha
   if ( combined )
   {
      // Color-preserving: one black/white point on the combined RGB/K channel.
      var lo = image.minimum( new Rect(), 0, n - 1 );
      var hi = image.maximum( new Rect(), 0, n - 1 );
      if ( hi - lo > 1.0e-6 )
         H[3] = [ lo, 0.5, hi, 0, 1 ];
   }
   else
   {
      for ( var c = 0; c < n; ++c )
      {
         var loc = image.minimum( new Rect(), c, c );
         var hic = image.maximum( new Rect(), c, c );
         if ( hic - loc > 1.0e-6 )
            H[c] = [ loc, 0.5, hic, 0, 1 ]; // c0 = min, c1 = max -> no clipping
      }
   }
   var ht = new HistogramTransformation;
   ht.H = H;
   ht.executeOn( view, false/*swapFile*/ );
}

/*
 * Creates a new (hidden) image window holding a copy of the given source
 * window's image, optionally integer-downsampled by |zoomFactor| (a negative
 * integer; 0 or -1 means no downsampling).
 */
function makeDownsampledCopy( srcWindow, newId, zoomFactor )
{
   var img = srcWindow.mainView.image;
   var w = new ImageWindow( img.width, img.height, img.numberOfChannels,
                            srcWindow.bitsPerSample, srcWindow.isFloatSample,
                            false/*color*/, newId );
   w.mainView.beginProcess( UndoFlag.NoSwapFile );
   w.mainView.image.apply( img );
   w.mainView.endProcess();

   if ( zoomFactor < -1 )
   {
      var ir = new IntegerResample;
      ir.zoomFactor = zoomFactor;
      ir.downsamplingMode = IntegerResample.Average;
      ir.executeOn( w.mainView, false/*swapFile*/ );
   }
   return w;
}

/*
 * Applies an STF-style automatic stretch to a view, in place (destructive).
 * Used on disposable preview/palette copies. A lower targetBackground yields a
 * darker background.
 */
function autoStretchView( view, targetBackground )
{
   var shadowsClipping = -2.80;
   if ( targetBackground === undefined )
      targetBackground = 0.25;

   var image  = view.image;
   var median = image.median();
   var mad    = image.MAD() * 1.4826;
   if ( mad == 0 )
      mad = 1.0;

   var c0 = Math.range( median + shadowsClipping * mad, 0.0, 1.0 );
   var m  = Math.mtf( targetBackground, median - c0 );

   var ht = new HistogramTransformation;
   ht.H = [ [ 0,  0.5, 1, 0, 1 ],
            [ 0,  0.5, 1, 0, 1 ],
            [ 0,  0.5, 1, 0, 1 ],
            [ c0, m,   1, 0, 1 ],
            [ 0,  0.5, 1, 0, 1 ] ];
   ht.executeOn( view, false/*swapFile*/ );
}

/*
 * Like autoStretchView() but computes independent stretch parameters for each
 * R, G, B channel. Use for colour images where channels may have very different
 * signal levels (e.g. Foraxx palettes).
 */
function autoStretchPerChannel( view, targetBackground )
{
   var shadowsClipping = -2.80;
   if ( targetBackground === undefined )
      targetBackground = 0.25;
   var image = view.image;
   var n = Math.min( 3, image.numberOfChannels );
   var H = [ [ 0, 0.5, 1, 0, 1 ],
             [ 0, 0.5, 1, 0, 1 ],
             [ 0, 0.5, 1, 0, 1 ],
             [ 0, 0.5, 1, 0, 1 ],
             [ 0, 0.5, 1, 0, 1 ] ];
   var rect = new Rect( 0, 0, image.width, image.height );
   for ( var c = 0; c < n; ++c )
   {
      var median = image.median( rect, c, c );
      var mad    = image.MAD( median, rect, c, c ) * 1.4826;
      if ( mad == 0 ) mad = 1.0;
      var c0 = Math.range( median + shadowsClipping * mad, 0.0, 1.0 );
      var m  = Math.mtf( targetBackground, median - c0 );
      H[c] = [ c0, m, 1, 0, 1 ];
   }
   var ht = new HistogramTransformation;
   ht.H = H;
   ht.executeOn( view, false/*swapFile*/ );
}

/*
 * Forces a linear (identity) screen transfer function on a view, so a linear
 * image is also displayed linearly (not auto-stretched on screen). This does
 * not modify pixel data.
 */
function resetLinearSTF( view )
{
   var stf = new ScreenTransferFunction;
   stf.STF = [ [ 0, 1, 0.5, 0, 1 ],
               [ 0, 1, 0.5, 0, 1 ],
               [ 0, 1, 0.5, 0, 1 ],
               [ 0, 1, 0.5, 0, 1 ] ];
   stf.executeOn( view );
}

/*
 * Builds a valid, unique view identifier from a base name.
 */
function uniqueViewId( baseId )
{
   var id = baseId.replace( /[^0-9A-Za-z_]/g, "_" );
   if ( id.length == 0 || (id[0] >= '0' && id[0] <= '9') )
      id = "_" + id;
   var candidate = id;
   for ( var i = 1; ; ++i )
   {
      var w = ImageWindow.windowById( candidate );
      if ( w === null || w.isNull )
         break;
      candidate = id + "_" + i;
   }
   return candidate;
}

/*
 * Script parameters.
 */
function OSCNBData()
{
   var window = ImageWindow.activeWindow;
   this.targetView  = window.isNull ? null : window.currentView;
   this.extractHa   = true;
   this.extractOIII = true;
   this.haBandpass  = 5.0;
   this.oiiiBandpass = 5.0;
   this.extractSII  = true;
   this.siiAmount   = 0.50;
   this.extractLum  = true;
   this.lumAmount   = 0.50;
   this.createHOO          = false;
   this.createHaOIIIForaxx = false;
   this.createSHO          = false;
   this.createForaxx       = false;
}

var data = new OSCNBData;

var OSCNBPreviewDialog = class extends Dialog
{
   constructor()
   {
      super();

      // Interactive state.
      this.haWindow      = null;
      this.oiiiWindow    = null;
      this.siiWindow     = null;
      this.lumWindow     = null;
      this.smallHa       = null;
      this.smallOiii     = null;
      this.smallSII      = null;
      this.smallLum      = null;
      this.previewBitmap    = null;
      this.haPreviewBitmap  = null;
      this.oiiiPreviewBitmap = null;
      this.lumPreviewBitmap  = null;
      this.previewDone   = false;
      this.channelsDone  = false;
      this.siiDone       = false;
      this.nonLinear     = false;

      var labelWidth1 = this.font.width( "OIII bandpass (nm):" + 'T' );

      //

      var helpText = new Label( this );
      helpText.margin = 4;
      helpText.wordWrapping = true;
      helpText.useRichText = true;
      helpText.text =
         "<p>This script extracts Ha, OIII, and optionally generates Synthetic SII/Lum data from OSC dual Ha-OIII narrowband "
         + "linear images. For best results, remove stars and perform noise reduction before running this script.</p>"
         + "<ol>"
         + "<li>Click <b>Preview</b> to generate narrowband channel previews</li>"
         + "<li>Click <b>Preview</b> to update any changes made to the Ha/OIII parameters</li>"
         + "<li>If <b>Synthetic SII</b> is selected, <b>SII Amount</b> slider will dynamically update the Synthetic SII preview</li>"
         + "<li>If <b>Synthetic Luminosity</b> is selected, <b>Lum blend</b> slider will dynamically update the Synthetic Lum preview</li>"
         + "<li>Select palettes to create non-linear (stretched) images</li>"
         + "<li>Click <b>Extract</b> to create linear narrowband channels and non-linear palettes</li>"
         + "</ol>"
         + "<p>&copy; 2026 Loran Hughes, WestwoodAstro.net</p>";

      this.helpLabel = new GroupBox( this );
      this.helpLabel.title = TITLE + " v" + VERSION;
      this.helpLabel.sizer = new VerticalSizer;
      this.helpLabel.sizer.margin = 6;
      this.helpLabel.sizer.add( helpText );

      // Target image
      this.targetImage_Label = new Label( this );
      this.targetImage_Label.minWidth = labelWidth1;
      this.targetImage_Label.text = "Target image:";
      this.targetImage_Label.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;

      this.targetImage_ViewList = new ViewList( this );
      this.targetImage_ViewList.scaledMinWidth = 240;
      this.targetImage_ViewList.getAll();
      if ( data.targetView !== null )
      {
         this.targetImage_ViewList.currentView = data.targetView;
         this.nonLinear = ( data.targetView.image.numberOfChannels < 3 ||
                            data.targetView.image.median() > 0.1 );
      }
      this.targetImage_ViewList.toolTip = "Select the OSC dual-band RGB image to extract from.";
      this.targetImage_ViewList.onViewSelected = ( view ) =>
      {
         data.targetView = view;
         this.nonLinear = ( view !== null && !view.isNull &&
                            ( view.image.numberOfChannels < 3 ||
                              view.image.median() > 0.1 ) );
         if ( this.nonLinear )
         {
            this.closePreview();
            this.previewDone = false;
         }
         this.previewControl.repaint();
         this.updateControls();
      };

      this.targetImage_Sizer = new HorizontalSizer;
      this.targetImage_Sizer.spacing = 4;
      this.targetImage_Sizer.add( this.targetImage_Label );
      this.targetImage_Sizer.add( this.targetImage_ViewList, 100 );

      // Channels to extract (Ha and OIII are always extracted)
      this.extractSII_CheckBox = new CheckBox( this );
      this.extractSII_CheckBox.text = "Synthetic SII";
      this.extractSII_CheckBox.checked = data.extractSII;
      this.extractSII_CheckBox.toolTip =
         "<p>Enable synthetic SII extraction.</p>";
      this.extractSII_CheckBox.onCheck = ( checked ) =>
      {
         data.extractSII = checked;
         if ( !checked )
         {
            // SHO/Foraxx need SII; clear them when their options are hidden.
            data.createSHO = false;
            data.createForaxx = false;
            this.sho_CheckBox.checked = false;
            this.foraxx_CheckBox.checked = false;
            // Destroy the SII preview resources; repaint will show "not selected".
            if ( this.smallSII !== null && !this.smallSII.isNull )
               this.smallSII.forceClose();
            this.smallSII = null;
            this.previewBitmap = null;
            this.previewControl.repaint();
         }
         else if ( this.smallHa !== null )
         {
            // Re-create the SII preview from the existing downsampled Ha copy.
            this.smallSII = makeDownsampledCopy( this.smallHa,
                               uniqueViewId( data.targetView.id + "_SII_prev" ), 0 );
            this.updatePreview();
         }
         else
         {
            this.previewControl.repaint(); // clears "Not Selected" message immediately
         }
         this.showPreviewPanel( checked );
         this.updateControls();
      };

      this.extractLum_CheckBox = new CheckBox( this );
      this.extractLum_CheckBox.text = "Synthetic Luminosity";
      this.extractLum_CheckBox.checked = data.extractLum;
      this.extractLum_CheckBox.toolTip =
         "<p>Create a synthetic luminosity channel blended from Ha and OIII.</p>";
      this.extractLum_CheckBox.onCheck = ( checked ) =>
      {
         data.extractLum = checked;
         if ( !checked )
         {
            if ( this.smallLum !== null && !this.smallLum.isNull )
               this.smallLum.forceClose();
            this.smallLum = null;
            this.lumPreviewBitmap = null;
            this.lumPreviewControl.repaint();
         }
         else if ( this.smallHa !== null )
         {
            this.smallLum = makeDownsampledCopy( this.smallHa,
                               uniqueViewId( data.targetView.id + "_Lum_prev" ), 0 );
            this.updateLumPreview(); // triggers repaint
         }
         else
         {
            this.lumPreviewControl.repaint(); // clears "Not Selected" message immediately
         }
         this.updateControls();
      };

      this.channels_Sizer = new HorizontalSizer;
      this.channels_Sizer.spacing = 8;
      this.channels_Sizer.add( this.extractSII_CheckBox );
      this.channels_Sizer.add( this.extractLum_CheckBox );
      this.channels_Sizer.addStretch();

      // OIII combination
      // Ha bandpass
      this.haBandpass_NC = new NumericControl( this );
      this.haBandpass_NC.label.text = "Ha bandpass (nm):";
      this.haBandpass_NC.label.minWidth = labelWidth1;
      this.haBandpass_NC.setRange( 0.5, 15.0 );
      this.haBandpass_NC.slider.setRange( 5, 150 );
      this.haBandpass_NC.slider.scaledMinWidth = 200;
      this.haBandpass_NC.setPrecision( 1 );
      this.haBandpass_NC.setValue( data.haBandpass );
      this.haBandpass_NC.toolTip =
         "<p>Ha filter bandpass (FWHM) in nm. Scales the Ha bleed-correction "
         + "coefficients in the Ha-corrected OIII formula. Default is 5 nm.</p>";
      this.haBandpass_NC.onValueUpdated = ( value ) =>
      {
         data.haBandpass = value;
      };

      // OIII bandpass
      this.oiiiBandpass_NC = new NumericControl( this );
      this.oiiiBandpass_NC.label.text = "OIII bandpass (nm):";
      this.oiiiBandpass_NC.label.minWidth = labelWidth1;
      this.oiiiBandpass_NC.setRange( 0.5, 15.0 );
      this.oiiiBandpass_NC.slider.setRange( 5, 150 );
      this.oiiiBandpass_NC.slider.scaledMinWidth = 200;
      this.oiiiBandpass_NC.setPrecision( 1 );
      this.oiiiBandpass_NC.setValue( data.oiiiBandpass );
      this.oiiiBandpass_NC.toolTip =
         "<p>OIII filter bandpass (FWHM) in nm. Adjusts the green/blue channel "
         + "mixing weights in the Ha-corrected OIII formula: wider bandpass "
         + "increases the green contribution. Default is 5 nm. </p>";
      this.oiiiBandpass_NC.onValueUpdated = ( value ) =>
      {
         data.oiiiBandpass = value;
      };

      // Synthetic SII coefficient (live)
      this.siiAmount_NC = new NumericControl( this );
      this.siiAmount_NC.label.text = "SII amount (k):";
      this.siiAmount_NC.label.minWidth = labelWidth1;
      this.siiAmount_NC.setRange( 0.0, 1.0 );
      this.siiAmount_NC.slider.setRange( 0, 100 );
      this.siiAmount_NC.slider.scaledMinWidth = 200;
      this.siiAmount_NC.setPrecision( 2 );
      this.siiAmount_NC.setValue( data.siiAmount );
      this.siiAmount_NC.toolTip =
         "<p>Residual coefficient <i>k</i>: SII = max( 0, Ha &minus; "
         + "k&times;(OIII &minus; med(OIII)) ). Default is 0.5. Updates the preview dynamically.</p>";
      this.siiAmount_NC.onValueUpdated = ( value ) =>
      {
         data.siiAmount = value;
         this.updatePreview();
      };

      // Synthetic Lum blend (live)
      this.lumAmount_NC = new NumericControl( this );
      this.lumAmount_NC.label.text = "Lum blend (OIII-Ha):";
      this.lumAmount_NC.label.minWidth = labelWidth1;
      this.lumAmount_NC.setRange( 0.0, 1.0 );
      this.lumAmount_NC.slider.setRange( 0, 100 );
      this.lumAmount_NC.slider.scaledMinWidth = 200;
      this.lumAmount_NC.setPrecision( 2 );
      this.lumAmount_NC.setValue( data.lumAmount );
      this.lumAmount_NC.toolTip =
         "<p>Blend ratio between Ha and OIII for the synthetic luminosity channel. "
         + "At 1.0 the result is pure Ha; at 0.0 it is pure OIII. "
         + "Default is 0.5 (equal blend). Updates the preview dynamically.</p>";
      this.lumAmount_NC.onValueUpdated = ( value ) =>
      {
         data.lumAmount = value;
         if ( this.smallLum !== null )
            this.updateLumPreview();
      };

      this.previewParams_Button = new PushButton( this );
      this.previewParams_Button.text = "Preview";
      this.previewParams_Button.icon = this.scaledResource( ":/icons/find.png" );
      this.previewParams_Button.toolTip =
         "<p>Generate screen-stretched channel previews. "
         + "Adjust <b>SII amount</b> and click <b>Preview</b> again to "
         + "update. Click <b>Extract</b> when satisfied.</p>";
      this.previewParams_Button.onClick = () =>
      {
         this.onPreview();
      };

      this.resetParams_Button = new PushButton( this );
      this.resetParams_Button.text = "Reset Defaults";
      this.resetParams_Button.icon = this.scaledResource( ":/icons/reload.png" );
      this.resetParams_Button.toolTip =
         "<p>Reset all extraction parameters to their default values.</p>";
      this.resetParams_Button.onClick = () =>
      {
         data.haBandpass  = 5.0;
         data.oiiiBandpass = 5.0;
         data.siiAmount   = 0.50;
         data.lumAmount   = 0.50;
         this.haBandpass_NC.setValue( data.haBandpass );
         this.oiiiBandpass_NC.setValue( data.oiiiBandpass );
         this.siiAmount_NC.setValue( data.siiAmount );
         this.lumAmount_NC.setValue( data.lumAmount );
         if ( this.smallHa !== null )
            this.onPreview();
      };

      this.previewBtn_Sizer = new HorizontalSizer;
      this.previewBtn_Sizer.spacing = 4;
      this.previewBtn_Sizer.add( this.resetParams_Button );
      this.previewBtn_Sizer.addStretch();
      this.previewBtn_Sizer.add( this.previewParams_Button );

      this.par_GroupBox = new GroupBox( this );
      this.par_GroupBox.title = "Extraction Parameters";
      this.par_GroupBox.sizer = new VerticalSizer;
      this.par_GroupBox.sizer.margin = 6;
      this.par_GroupBox.sizer.spacing = 4;
      this.par_GroupBox.sizer.add( this.channels_Sizer );
      this.par_GroupBox.sizer.add( this.haBandpass_NC );
      this.par_GroupBox.sizer.add( this.oiiiBandpass_NC );
      this.par_GroupBox.sizer.add( this.siiAmount_NC );
      this.par_GroupBox.sizer.add( this.lumAmount_NC );
      this.par_GroupBox.sizer.add( this.previewBtn_Sizer );

      // Palette options. HOO is always available (Ha/OIII only); SHO and Foraxx
      // require the synthetic SII and are shown only when it is checked.
      this.hoo_CheckBox = new CheckBox( this );
      this.hoo_CheckBox.text = "Create HOO Palette Image";
      this.hoo_CheckBox.checked = data.createHOO;
      this.hoo_CheckBox.toolTip =
         "<p>Combine statistically-stretched copies of Ha and OIII into an "
         + "HOO bicolor palette image: R = Ha, G = OIII, B = OIII.</p>";
      this.hoo_CheckBox.onCheck = ( checked ) =>
      {
         data.createHOO = checked;
      };

      this.haOIIIForaxx_CheckBox = new CheckBox( this );
      this.haOIIIForaxx_CheckBox.text = "Create 2-Channel (Ha-OIII) Foraxx Palette Image";
      this.haOIIIForaxx_CheckBox.checked = data.createHaOIIIForaxx;
      this.haOIIIForaxx_CheckBox.toolTip =
         "<p>Combine statistically-stretched copies of Ha and OIII into a "
         + "two-channel Foraxx dynamic palette image (no SII).</p>";
      this.haOIIIForaxx_CheckBox.onCheck = ( checked ) =>
      {
         data.createHaOIIIForaxx = checked;
      };

      this.sho_CheckBox = new CheckBox( this );
      this.sho_CheckBox.text = "Create SHO Palette Image";
      this.sho_CheckBox.checked = data.createSHO;
      this.sho_CheckBox.toolTip =
         "<p>Combine a statistically-stretched copy of each channel into an "
         + "SHO (Hubble) palette image: R = SII, G = Ha, B = OIII.</p>";
      this.sho_CheckBox.onCheck = ( checked ) =>
      {
         data.createSHO = checked;
      };

      this.foraxx_CheckBox = new CheckBox( this );
      this.foraxx_CheckBox.text = "Create 3-Channel (Ha-OIII-SII) Foraxx Palette Image";
      this.foraxx_CheckBox.toolTip =
         "<p>Combine statistically-stretched copies of Ha, OIII and SII into a "
         + "three-channel Foraxx dynamic palette image.</p>";
      this.foraxx_CheckBox.checked = data.createForaxx;
      this.foraxx_CheckBox.onCheck = ( checked ) =>
      {
         data.createForaxx = checked;
      };

      this.palette_GroupBox = new GroupBox( this );
      this.palette_GroupBox.title = "Palette Combinations (optional)";
      this.palette_GroupBox.sizer = new VerticalSizer;
      this.palette_GroupBox.sizer.margin = 6;
      this.palette_GroupBox.sizer.spacing = 4;
      this.palette_GroupBox.sizer.add( this.hoo_CheckBox );
      this.palette_GroupBox.sizer.add( this.haOIIIForaxx_CheckBox );
      this.palette_GroupBox.sizer.add( this.sho_CheckBox );
      this.palette_GroupBox.sizer.add( this.foraxx_CheckBox );

      this.left_Sizer = new VerticalSizer;
      this.left_Sizer.spacing = 6;
      this.nonLinearWarning_Label = new Label( this );
      this.nonLinearWarning_Label.useRichText = true;
      this.nonLinearWarning_Label.wordWrapping = true;
      this.nonLinearWarning_Label.text =
         "<p><font color=\"#ff4040\"><b>Warning:</b> Selected image is not a linear RGB color image. "
         + "A linear (unstretched) RGB color image is required.</font></p>";
      this.nonLinearWarning_Label.visible = this.nonLinear;

      this.left_Sizer.add( this.targetImage_Sizer );
      this.left_Sizer.add( this.nonLinearWarning_Label );
      this.left_Sizer.add( this.par_GroupBox );
      this.left_Sizer.add( this.palette_GroupBox );
      this.left_Sizer.add( this.helpLabel );
      this.left_Sizer.addStretch();

      // Preview panel (right) — Synthetic SII (left), Ha (centre), OIII (right).
      this.previewControl = new Control( this );
      this.previewControl.setScaledFixedSize( PREVIEW_SIZE + 16, PREVIEW_SIZE + 16 );
      this.previewControl.toolTip = "<p>Screen-stretched, downsampled preview of the synthetic SII channel. "
         + "Updates live as the SII amount slider is adjusted.</p>";
      this.previewControl.onPaint = ( x0, y0, x1, y1 ) =>
      {
         var g = new Graphics( this.previewControl );
         g.brush = new Brush( 0xff101010 );
         g.pen = new Pen( 0xff101010 );
         g.fillRect( 0, 0, this.previewControl.width, this.previewControl.height );
         if ( this.previewBitmap !== null )
         {
            var px = Math.round( (this.previewControl.width  - this.previewBitmap.width ) / 2 );
            var py = Math.round( (this.previewControl.height - this.previewBitmap.height) / 2 );
            g.drawBitmap( px, py, this.previewBitmap );
         }
         else if ( !data.extractSII )
         {
            var lines = [ "Synthetic SII", "Not Selected" ];
            g.pen = new Pen( 0xffa0a0a0 );
            var lh = g.font.ascent + g.font.descent;
            var spacing = Math.round( lh * 0.3 );
            var totalH = lines.length * lh + (lines.length - 1) * spacing;
            var ty = Math.round( (this.previewControl.height - totalH) / 2 );
            for ( var i = 0; i < lines.length; ++i )
            {
               var lw = g.font.width( lines[i] );
               var tx = Math.round( (this.previewControl.width - lw) / 2 );
               g.drawText( tx, ty + i * (lh + spacing) + g.font.ascent, lines[i] );
            }
         }
         g.end();
      };

      this.haPreviewControl = new Control( this );
      this.haPreviewControl.setScaledFixedSize( PREVIEW_SIZE + 16, PREVIEW_SIZE + 16 );
      this.haPreviewControl.toolTip = "<p>Screen-stretched, downsampled preview of the Ha channel (reference).</p>";
      this.haPreviewControl.onPaint = ( x0, y0, x1, y1 ) =>
      {
         var g = new Graphics( this.haPreviewControl );
         g.brush = new Brush( 0xff101010 );
         g.pen = new Pen( 0xff101010 );
         g.fillRect( 0, 0, this.haPreviewControl.width, this.haPreviewControl.height );
         if ( this.haPreviewBitmap !== null )
         {
            var px = Math.round( (this.haPreviewControl.width  - this.haPreviewBitmap.width ) / 2 );
            var py = Math.round( (this.haPreviewControl.height - this.haPreviewBitmap.height) / 2 );
            g.drawBitmap( px, py, this.haPreviewBitmap );
         }
         g.end();
      };

      this.oiiiPreviewControl = new Control( this );
      this.oiiiPreviewControl.setScaledFixedSize( PREVIEW_SIZE + 16, PREVIEW_SIZE + 16 );
      this.oiiiPreviewControl.toolTip = "<p>Screen-stretched, downsampled preview of the OIII channel (reference).</p>";
      this.oiiiPreviewControl.onPaint = ( x0, y0, x1, y1 ) =>
      {
         var g = new Graphics( this.oiiiPreviewControl );
         g.brush = new Brush( 0xff101010 );
         g.pen = new Pen( 0xff101010 );
         g.fillRect( 0, 0, this.oiiiPreviewControl.width, this.oiiiPreviewControl.height );
         if ( this.oiiiPreviewBitmap !== null )
         {
            var px = Math.round( (this.oiiiPreviewControl.width  - this.oiiiPreviewBitmap.width ) / 2 );
            var py = Math.round( (this.oiiiPreviewControl.height - this.oiiiPreviewBitmap.height) / 2 );
            g.drawBitmap( px, py, this.oiiiPreviewBitmap );
         }
         g.end();
      };

      this.lumPreviewControl = new Control( this );
      this.lumPreviewControl.setScaledFixedSize( PREVIEW_SIZE + 16, PREVIEW_SIZE + 16 );
      this.lumPreviewControl.toolTip =
         "<p>Screen-stretched, downsampled preview of the synthetic luminosity channel.</p>";
      this.lumPreviewControl.onPaint = ( x0, y0, x1, y1 ) =>
      {
         var g = new Graphics( this.lumPreviewControl );
         g.brush = new Brush( 0xff101010 );
         g.pen = new Pen( 0xff101010 );
         g.fillRect( 0, 0, this.lumPreviewControl.width, this.lumPreviewControl.height );
         if ( this.lumPreviewBitmap !== null )
         {
            var px = Math.round( (this.lumPreviewControl.width  - this.lumPreviewBitmap.width ) / 2 );
            var py = Math.round( (this.lumPreviewControl.height - this.lumPreviewBitmap.height) / 2 );
            g.drawBitmap( px, py, this.lumPreviewBitmap );
         }
         else if ( !data.extractLum )
         {
            var lines = [ "Synthetic Lum", "Not Selected" ];
            g.pen = new Pen( 0xffa0a0a0 );
            var lh = g.font.ascent + g.font.descent;
            var spacing = Math.round( lh * 0.3 );
            var totalH = lines.length * lh + (lines.length - 1) * spacing;
            var ty = Math.round( (this.lumPreviewControl.height - totalH) / 2 );
            for ( var i = 0; i < lines.length; ++i )
            {
               var lw = g.font.width( lines[i] );
               var tx = Math.round( (this.lumPreviewControl.width - lw) / 2 );
               g.drawText( tx, ty + i * (lh + spacing) + g.font.ascent, lines[i] );
            }
         }
         g.end();
      };

      this.siiPreviewLabel = new Label( this );
      this.siiPreviewLabel.text = "Synthetic SII";
      this.siiPreviewLabel.textAlignment = TextAlignment.Center|TextAlignment.VertCenter;

      this.haPreviewLabel = new Label( this );
      this.haPreviewLabel.text = "Ha";
      this.haPreviewLabel.textAlignment = TextAlignment.Center|TextAlignment.VertCenter;

      this.oiiiPreviewLabel = new Label( this );
      this.oiiiPreviewLabel.text = "OIII";
      this.oiiiPreviewLabel.textAlignment = TextAlignment.Center|TextAlignment.VertCenter;

      this.lumPreviewLabel = new Label( this );
      this.lumPreviewLabel.text = "Synthetic Lum";
      this.lumPreviewLabel.textAlignment = TextAlignment.Center|TextAlignment.VertCenter;

      // Top row: Synthetic SII (left) and Ha (right).
      this.haPreviewCol_Sizer = new VerticalSizer;
      this.haPreviewCol_Sizer.spacing = 2;
      this.haPreviewCol_Sizer.add( this.haPreviewLabel );
      this.haPreviewCol_Sizer.add( this.haPreviewControl );

      this.oiiiPreviewCol_Sizer = new VerticalSizer;
      this.oiiiPreviewCol_Sizer.spacing = 2;
      this.oiiiPreviewCol_Sizer.add( this.oiiiPreviewLabel );
      this.oiiiPreviewCol_Sizer.add( this.oiiiPreviewControl );

      // Top row: Ha (left) and OIII (right).
      this.topRow_Sizer = new HorizontalSizer;
      this.topRow_Sizer.spacing = 8;
      this.topRow_Sizer.add( this.haPreviewCol_Sizer );
      this.topRow_Sizer.add( this.oiiiPreviewCol_Sizer );

      this.siiPreviewCol_Sizer = new VerticalSizer;
      this.siiPreviewCol_Sizer.spacing = 2;
      this.siiPreviewCol_Sizer.add( this.siiPreviewLabel );
      this.siiPreviewCol_Sizer.add( this.previewControl );

      this.lumPreviewCol_Sizer = new VerticalSizer;
      this.lumPreviewCol_Sizer.spacing = 2;
      this.lumPreviewCol_Sizer.add( this.lumPreviewLabel );
      this.lumPreviewCol_Sizer.add( this.lumPreviewControl );

      // Bottom row: Synthetic SII (left) and Synthetic Lum (right).
      this.bottomRow_Sizer = new HorizontalSizer;
      this.bottomRow_Sizer.spacing = 8;
      this.bottomRow_Sizer.add( this.siiPreviewCol_Sizer );
      this.bottomRow_Sizer.add( this.lumPreviewCol_Sizer );

      this.previews_Sizer = new VerticalSizer;
      this.previews_Sizer.spacing = 8;
      this.previews_Sizer.add( this.topRow_Sizer );
      this.previews_Sizer.add( this.bottomRow_Sizer );

      this.preview_GroupBox = new GroupBox( this );
      this.preview_GroupBox.title = "Channel Previews (screen-stretched)";
      this.preview_GroupBox.sizer = new VerticalSizer;
      this.preview_GroupBox.sizer.margin = 6;
      this.preview_GroupBox.sizer.add( this.previews_Sizer );

      // Controls + preview, side by side
      this.content_Sizer = new HorizontalSizer;
      this.content_Sizer.spacing = 8;
      this.content_Sizer.add( this.left_Sizer, 100 );
      this.content_Sizer.add( this.preview_GroupBox );

      // Buttons
      this.extract_Button = new PushButton( this );
      this.extract_Button.text = "Extract";
      this.extract_Button.icon = this.scaledResource( ":/icons/execute.png" );
      this.extract_Button.toolTip =
         "<p>Create all selected narrowband channels and palettes, then close.</p>";
      this.extract_Button.onClick = () =>
      {
         this.onExtract();
      };

      this.close_Button = new PushButton( this );
      this.close_Button.text = "Close";
      this.close_Button.icon = this.scaledResource( ":/icons/close.png" );
      this.close_Button.onClick = () =>
      {
         this.closePreview();
         this.ok();
      };

      this.buttons_Sizer = new HorizontalSizer;
      this.buttons_Sizer.spacing = 4;
      this.buttons_Sizer.add( this.extract_Button );
      this.buttons_Sizer.addStretch();
      this.buttons_Sizer.add( this.close_Button );

      this.sizer = new VerticalSizer;
      this.sizer.margin = 8;
      this.sizer.spacing = 6;
      this.sizer.add( this.content_Sizer );
      this.sizer.addSpacing( 4 );
      this.sizer.add( this.buttons_Sizer );

      // The preview panel is always visible. SHO/3-channel Foraxx palette options are
      // shown only when Synthetic SII is checked.
      this.sho_CheckBox.visible    = data.extractSII;
      this.foraxx_CheckBox.visible = data.extractSII;

      this.windowTitle = TITLE + " v" + VERSION;
      this.adjustToContents();
      this.setFixedSize();

      this.updateControls();

      // Safety net: close any remaining preview windows regardless of how the
      // dialog is dismissed (Extract button, Close button, Escape, window X).
      this.onReturn = ( retVal ) =>
      {
         // Safety net: ensure all temporary windows are gone regardless of
         // how the dialog was dismissed.
         this.closePreview();
         this.disposeUnkeptChannels();
      };
   }

   // --- Interactive logic -------------------------------------------------

   showPreviewPanel( show )
   {
      this.sho_CheckBox.visible    = show;
      this.foraxx_CheckBox.visible = show;
      // Resize the (otherwise fixed-size) dialog to fit the updated left panel.
      this.setVariableSize();
      this.adjustToContents();
      this.setFixedSize();
   }

   validateInputs()
   {
      if ( data.targetView === null || data.targetView.isNull )
      {
         ( new MessageBox( "Please select a target view.",
                           TITLE, StdIcon.Error, StdButton.Ok ) ).execute();
         return false;
      }
      if ( data.targetView.image.numberOfChannels < 3 )
      {
         ( new MessageBox( "The target image must be an RGB color image (at least 3 channels).",
                           TITLE, StdIcon.Error, StdButton.Ok ) ).execute();
         return false;
      }
      if ( !data.extractHa && !data.extractOIII && !data.extractSII && !data.extractLum
           && !data.createHOO && !data.createHaOIIIForaxx
           && !data.createSHO && !data.createForaxx )
      {
         ( new MessageBox( "Select at least one of Ha, OIII, synthetic SII, synthetic Lum, or a palette.",
                           TITLE, StdIcon.Error, StdButton.Ok ) ).execute();
         return false;
      }
      return true;
   }

   onPreview()
   {
      if ( this.channelsDone ) return;
      if ( !this.validateInputs() ) return;

      var view   = data.targetView;
      var baseId = view.id;

      // Extract into hidden windows that are never shown to the user.
      var tempHa = extractChannelHidden( view, "$T[0]",
                      uniqueViewId( baseId + "_Ha_tmp" ) );
      var tempOiii = extractChannelHidden( view,
                        oiiiExpression( data.haBandpass, data.oiiiBandpass ),
                        uniqueViewId( baseId + "_OIII_tmp" ) );
      linearFitTo( tempOiii.mainView, tempHa.mainView.id );
      applyFloor( tempHa.mainView,   MIN_K );
      applyFloor( tempOiii.mainView, MIN_K );

      // Discard any existing preview resources before rebuilding.
      this.closePreview();

      // Build downsampled preview copies and render bitmaps. The full-res temp
      // windows are closed immediately after — they are never shown to the user.
      this.openPreview( tempHa, tempOiii );
      tempHa.forceClose();
      tempOiii.forceClose();

      this.previewDone = true;
      this.updateControls();
   }

   onExtract()
   {
      if ( this.channelsDone ) return;
      if ( !this.validateInputs() ) return;

      this.ensureChannels();

      if ( data.extractSII )
      {
         if ( !this.finalizeSII() )
         {
            this.closePreview();
            this.disposeUnkeptChannels();
            this.updateControls();
            return;
         }
      }
      else
      {
         this.buildPalettes();
         this.disposeUnkeptChannels();
      }

      // Delete preview resources after all channels have been created.
      this.closePreview();
      this.ok();
   }

   disposeUnkeptChannels()
   {
      if ( !data.extractHa && this.haWindow !== null && !this.haWindow.isNull )
      {
         this.haWindow.forceClose();
         this.haWindow = null;
      }
      if ( !data.extractOIII && this.oiiiWindow !== null && !this.oiiiWindow.isNull )
      {
         this.oiiiWindow.forceClose();
         this.oiiiWindow = null;
      }
      if ( !data.extractLum && this.lumWindow !== null && !this.lumWindow.isNull )
      {
         this.lumWindow.forceClose();
         this.lumWindow = null;
      }
   }

   ensureChannels()
   {
      var view = data.targetView;
      var baseId = view.id;

      // SII and the palettes all need both Ha and OIII; generate them whenever
      // SII or any palette is requested, even if the user did not ask to keep
      // the mono channels.
      var anyPalette = data.createHOO || data.createHaOIIIForaxx
                       || data.createSHO || data.createForaxx;
      var needHa   = data.extractHa   || data.extractSII || data.extractLum || anyPalette;
      var needOIII = data.extractOIII || data.extractSII || data.extractLum || anyPalette;

      if ( needHa )
         this.haWindow = extractChannel( view, "$T[0]", uniqueViewId( baseId + "_Ha" ) );
      if ( needOIII )
         this.oiiiWindow = extractChannel( view,
                                           oiiiExpression( data.haBandpass, data.oiiiBandpass ),
                                           uniqueViewId( baseId + "_OIII" ) );

      // LinearFit OIII to Ha (both stay linear).
      if ( this.haWindow !== null && this.oiiiWindow !== null )
      {
         linearFitTo( this.oiiiWindow.mainView, this.haWindow.mainView.id );
         console.writeln( "<end><cbr>* OIII linearly fitted to " + this.haWindow.mainView.id );
      }

      // Clamp each channel to the minimum pixel floor.
      if ( this.haWindow !== null )
         applyFloor( this.haWindow.mainView, MIN_K );
      if ( this.oiiiWindow !== null )
         applyFloor( this.oiiiWindow.mainView, MIN_K );

      if ( data.extractHa && this.haWindow !== null )
      {
         resetLinearSTF( this.haWindow.mainView );
         this.haWindow.show();
         this.haWindow.zoomToOptimalFit();
         console.writeln( "<end><cbr>* Ha image created (linear): " + this.haWindow.mainView.id );
      }
      if ( data.extractOIII && this.oiiiWindow !== null )
      {
         resetLinearSTF( this.oiiiWindow.mainView );
         this.oiiiWindow.show();
         this.oiiiWindow.zoomToOptimalFit();
         console.writeln( "<end><cbr>* OIII image created (linear): " + this.oiiiWindow.mainView.id );
      }

      if ( data.extractLum && this.haWindow !== null && this.oiiiWindow !== null )
      {
         var lumExpr = lumExpression( data.lumAmount,
                                     this.haWindow.mainView.id, this.oiiiWindow.mainView.id );
         this.lumWindow = extractChannel( data.targetView, lumExpr,
                                         uniqueViewId( baseId + "_Synth_Lum" ) );
         linearFitTo( this.lumWindow.mainView, this.haWindow.mainView.id );
         applyFloor( this.lumWindow.mainView, MIN_K );
         resetLinearSTF( this.lumWindow.mainView );
         this.lumWindow.show();
         this.lumWindow.zoomToOptimalFit();
         console.writeln( "<end><cbr>* Synthetic Lum image created (linear): "
                          + this.lumWindow.mainView.id
                          + format( "  [blend = %.2f]", data.lumAmount ) );
      }

      this.channelsDone = true;
   }

   openPreview( haWin, oiiiWin )
   {
      // Accept explicit windows (Preview path — temp windows) or fall back to
      // the persistent extraction windows (Extract path).
      if ( haWin   === undefined ) haWin   = this.haWindow;
      if ( oiiiWin === undefined ) oiiiWin = this.oiiiWindow;
      if ( haWin === null || oiiiWin === null ) return;

      var baseId = data.targetView.id;

      // Integer-downsample factor so the longest side is about PREVIEW_SIZE px.
      var maxDim = Math.max( haWin.mainView.image.width,
                             haWin.mainView.image.height );
      var n = Math.max( 1, Math.round( maxDim / PREVIEW_SIZE ) );
      var zf = (n > 1) ? -n : 0;

      this.smallHa   = makeDownsampledCopy( haWin,   uniqueViewId( baseId + "_Ha_prev" ),   zf );
      this.smallOiii = makeDownsampledCopy( oiiiWin, uniqueViewId( baseId + "_OIII_prev" ), zf );

      // Render static Ha and OIII bitmaps from temporary stretched copies so
      // the linear smallHa and smallOiii stay usable for SII computation.
      var haRender = makeDownsampledCopy( this.smallHa,   uniqueViewId( baseId + "_Ha_render" ),   0 );
      autoStretchView( haRender.mainView, PREVIEW_BG );
      this.haPreviewBitmap = haRender.mainView.image.render();
      haRender.forceClose();
      this.haPreviewControl.repaint();

      var oiiiRender = makeDownsampledCopy( this.smallOiii, uniqueViewId( baseId + "_OIII_render" ), 0 );
      autoStretchView( oiiiRender.mainView, PREVIEW_BG );
      this.oiiiPreviewBitmap = oiiiRender.mainView.image.render();
      oiiiRender.forceClose();
      this.oiiiPreviewControl.repaint();

      // SII preview is only created when Synthetic SII is selected.
      if ( data.extractSII )
      {
         this.smallSII = makeDownsampledCopy( this.smallHa, uniqueViewId( baseId + "_SII_prev" ), 0 );
         this.updatePreview();
      }
      else
      {
         this.previewControl.repaint(); // draws "not selected" message
      }

      // Lum preview is only created when Synthetic Lum is selected.
      if ( data.extractLum )
      {
         this.smallLum = makeDownsampledCopy( this.smallHa, uniqueViewId( baseId + "_Lum_prev" ), 0 );
         this.updateLumPreview();
      }
      else
      {
         this.lumPreviewControl.repaint(); // draws "not selected" message
      }
   }

   updatePreview()
   {
      if ( this.smallSII === null )
         return;
      computeSIIInto( this.smallSII.mainView,
                      this.smallHa.mainView.id, this.smallOiii.mainView.id, data.siiAmount );
      autoStretchView( this.smallSII.mainView, PREVIEW_BG ); // destructive, on the small copy
      this.previewBitmap = this.smallSII.mainView.image.render();
      this.previewControl.repaint();
   }

   updateLumPreview()
   {
      if ( this.smallLum === null )
         return;
      computeLumInto( this.smallLum.mainView,
                      this.smallHa.mainView.id, this.smallOiii.mainView.id, data.lumAmount );
      autoStretchView( this.smallLum.mainView, PREVIEW_BG ); // destructive, on the small copy
      this.lumPreviewBitmap = this.smallLum.mainView.image.render();
      this.lumPreviewControl.repaint();
   }

   closePreview()
   {
      if ( this.smallSII   !== null && !this.smallSII.isNull )   this.smallSII.forceClose();
      if ( this.smallLum   !== null && !this.smallLum.isNull )   this.smallLum.forceClose();
      if ( this.smallHa    !== null && !this.smallHa.isNull )    this.smallHa.forceClose();
      if ( this.smallOiii  !== null && !this.smallOiii.isNull )  this.smallOiii.forceClose();
      this.smallSII = this.smallLum = this.smallHa = this.smallOiii = null;
      this.previewBitmap     = null;
      this.haPreviewBitmap   = null;
      this.oiiiPreviewBitmap = null;
      this.lumPreviewBitmap  = null;
      this.previewControl.repaint();
      this.haPreviewControl.repaint();
      this.oiiiPreviewControl.repaint();
      this.lumPreviewControl.repaint();
   }

   finalizeSII()
   {
      if ( !this.channelsDone || this.haWindow === null || this.oiiiWindow === null )
         return false;

      // Generate the full-resolution SII at the current amount, then fit to Ha.
      var expr = siiExpression( data.siiAmount,
                                this.haWindow.mainView.id, this.oiiiWindow.mainView.id );
      var sii = extractChannel( data.targetView, expr,
                                uniqueViewId( data.targetView.id + "_Synth_SII" ) );
      linearFitTo( sii.mainView, this.haWindow.mainView.id );
      applyFloor( sii.mainView, MIN_K );
      resetLinearSTF( sii.mainView );
      sii.show();
      sii.zoomToOptimalFit();
      this.siiWindow = sii;
      console.writeln( "<end><cbr>* Synthetic SII image created: " + sii.mainView.id
                       + format( "  [k = %.2f]", data.siiAmount ) );

      this.buildPalettes();
      this.disposeUnkeptChannels();

      this.siiDone = true;
      return true;
   }

   buildPalettes()
   {
      // SHO and Foraxx require the synthetic SII; HOO needs only Ha and OIII.
      var haveSII   = this.siiWindow !== null && !this.siiWindow.isNull;
      var wantSII   = ( data.createSHO || data.createForaxx ) && haveSII;
      var wantAny   = data.createHOO || data.createHaOIIIForaxx || wantSII;
      if ( !wantAny )
         return;
      if ( this.haWindow === null || this.oiiiWindow === null )
         return;

      var baseId = data.targetView.id;

      // Temporary, statistically-stretched copies of each channel. The original
      // Ha/OIII/SII windows are left linear and untouched.
      var haC   = makeDownsampledCopy( this.haWindow,   uniqueViewId( baseId + "_Ha_tmp" ),   0 );
      var oiiiC = makeDownsampledCopy( this.oiiiWindow, uniqueViewId( baseId + "_OIII_tmp" ), 0 );
      autoStretchView( haC.mainView,   PALETTE_BG );
      autoStretchView( oiiiC.mainView, PALETTE_BG );

      var H = haC.mainView.id, O = oiiiC.mainView.id;

      var siiC = null, S = null;
      if ( wantSII )
      {
         siiC = makeDownsampledCopy( this.siiWindow, uniqueViewId( baseId + "_SII_tmp" ), 0 );
         autoStretchView( siiC.mainView, PALETTE_BG );
         S = siiC.mainView.id;
      }

      // HOO bicolor palette: R = Ha, G = OIII, B = OIII.
      if ( data.createHOO )
      {
         var hoo = combineRGB( data.targetView, H, O, O, uniqueViewId( baseId + "_HOO" ) );
         if ( hoo !== null && !hoo.isNull )
         {
            setShadowsHighlights( hoo.mainView );
            hoo.show();
            hoo.zoomToOptimalFit();
            console.writeln( "<end><cbr>* HOO palette created: " + hoo.mainView.id );
         }
      }

      // Two-channel Ha-OIII Foraxx palette (no SII), per the Foraxx Palette
      // Utility twoChannels path:
      //   hoString = (Ha*OIII)^~(Ha*OIII)
      //   R = Ha
      //   G = (hoString)*Ha + ~(hoString)*OIII
      //   B = OIII
      if ( data.createHaOIIIForaxx )
      {
         var hoStr2 = "(" + H + "*" + O + ")^~(" + H + "*" + O + ")";
         var f2G = "(" + hoStr2 + ")*" + H + "+ ~(" + hoStr2 + ")*" + O;
         var fx2 = combineRGB( data.targetView, H, f2G, O, uniqueViewId( baseId + "_Foraxx_HaOIII" ) );
         if ( fx2 !== null && !fx2.isNull )
         {
            applyForaxxFinishing( fx2.mainView );
            autoStretchPerChannel( fx2.mainView, PALETTE_BG );
            fx2.show();
            fx2.zoomToOptimalFit();
            console.writeln( "<end><cbr>* Ha-OIII Foraxx palette created: " + fx2.mainView.id );
         }
      }

      // SHO (Hubble) palette: R = SII, G = Ha, B = OIII.
      if ( data.createSHO && S !== null )
      {
         var sho = combineRGB( data.targetView, S, H, O, uniqueViewId( baseId + "_SHO" ) );
         if ( sho !== null && !sho.isNull )
         {
            setShadowsHighlights( sho.mainView );
            sho.show();
            sho.zoomToOptimalFit();
            console.writeln( "<end><cbr>* SHO palette created: " + sho.mainView.id );
         }
      }

      // Foraxx three-channel dynamic palette (from Ha, OIII and SII)
      //   oString  = OIII^~OIII
      //   hoString = (Ha*OIII)^~(Ha*OIII)
      //   R = (oString)*SII  + ~(oString)*Ha
      //   G = (hoString)*Ha  + ~(hoString)*OIII
      //   B = OIII
      if ( data.createForaxx && S !== null )
      {
         var oStr  = O + "^~" + O;
         var hoStr = "(" + H + "*" + O + ")^~(" + H + "*" + O + ")";
         var fR = "(" + oStr  + ")*" + S + "+ ~(" + oStr  + ")*" + H;
         var fG = "(" + hoStr + ")*" + H + "+ ~(" + hoStr + ")*" + O;
         var fB = O;
         var fx = combineRGB( data.targetView, fR, fG, fB, uniqueViewId( baseId + "_Foraxx" ) );
         if ( fx !== null && !fx.isNull )
         {
            applyForaxxFinishing( fx.mainView );
            autoStretchPerChannel( fx.mainView, PALETTE_BG );
            fx.show();
            fx.zoomToOptimalFit();
            console.writeln( "<end><cbr>* Foraxx palette created: " + fx.mainView.id );
         }
      }

      // Delete the temporary channel copies.
      haC.forceClose();
      oiiiC.forceClose();
      if ( siiC !== null )
         siiC.forceClose();
   }

   updateControls()
   {
      var active = !this.channelsDone && !this.nonLinear;
      this.nonLinearWarning_Label.visible = this.nonLinear;
      this.targetImage_ViewList.enabled  = !this.channelsDone;
      this.resetParams_Button.enabled    = active;
      this.previewParams_Button.enabled  = active;
      this.extract_Button.enabled        = active;
      this.haBandpass_NC.enabled         = active;
      this.oiiiBandpass_NC.enabled       = active;
      this.siiAmount_NC.enabled          = active && data.extractSII;
      this.lumAmount_NC.enabled          = active && data.extractLum;
      this.extractSII_CheckBox.enabled   = active;
      this.extractLum_CheckBox.enabled   = active;
      this.hoo_CheckBox.enabled          = active;
      this.haOIIIForaxx_CheckBox.enabled = active;
      this.sho_CheckBox.enabled          = active && data.extractSII;
      this.foraxx_CheckBox.enabled       = active && data.extractSII;
   }
};

/*
 * Script entry point.
 */
function main()
{
   console.hide();

   if ( data.targetView === null || data.targetView.isNull )
   {
      ( new MessageBox( "There is no active image window!",
                        TITLE, StdIcon.Error, StdButton.Ok ) ).execute();
      return;
   }

   console.show();
   var dialog = new OSCNBPreviewDialog();
   dialog.execute();
}

main();
