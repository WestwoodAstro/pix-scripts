#engine v8

/*
   OSC Narrowband Extraction v1.0

   An interactive script that extracts grayscale Ha and OIII channels from a
   one-shot-color (OSC) linear image acquired through a dual-band narrowband
   filter, optionally synthesizes an SII channel with a live preview, and can
   assemble HOO, SHO and Foraxx (2- and 3-channel) color palettes.

   Generated channels (all outputs are linear):

      Ha   = the red channel ( $T[0] ).

      OIII = a selectable combination of the green and blue channels. The default
             "Ha-corrected" mode removes Ha bleed before combining:
                max( 0, 0.6*(G - 0.05*Ha) + 0.4*(B - 0.02*Ha) ).
             OIII is then LinearFit to Ha.

      SII  = max( 0, Ha - k*( OIII - med(OIII) ) ), then LinearFit to Ha. The
             output window is named "<image>_Synth_SII".

      Every generated channel is clamped to a minimum pixel value (MIN_K) and
      shown zoomed to optimal fit.

   Workflow:

      1. Select the dual-band OSC RGB image and the OIII combination, and check
         the channels and/or palettes to create.

      2. Click "Extract Ha/OIII" to create the linear Ha and OIII channels.
            - If "Synthetic SII" is NOT checked, any selected palettes are built
              and the dialog closes.
            - If it IS checked, the dialog stays open and a downsampled,
              screen-stretched preview of the SII channel appears to the right
              and updates live as the "SII amount (k)" slider is dragged.

      3. (Synthetic SII only) Click "Create SII" to generate the full-resolution
         SII channel, build any selected palettes, and close the dialog.

   Palettes (optional):

      Each palette is built from temporary, statistically-stretched copies of the
      channels it needs; the copies are deleted afterward and the linear source
      channels are left untouched. The shadows and highlights of each palette are
      then set to the data extremes, without clipping.

      Always available (Ha and OIII only):
         HOO              = R: Ha   G: OIII  B: OIII   (bicolor).
         2-Channel Foraxx = a dynamic Ha/OIII palette (per the Foraxx Palette
                            Utility), with curves and selective-saturation
                            finishing.

      Available only when Synthetic SII is selected:
         SHO              = R: SII  G: Ha    B: OIII   (Hubble mapping).
         3-Channel Foraxx = a dynamic Ha/OIII/SII palette, with the same Foraxx
                            finishing.

   The live synthetic SII preview is a display-only stretched rendition; it never
   alters the generated channels, which always remain linear.

   Copyright (C) 2026 Loran Hughes, WestwoodAstro.net
   
   Foraxx palette generation pixelmath based on the The Coldest Nights website
   https://thecoldestnights.com/2020/06/pixinsight-dynamic-narrowband-combinations-with-pixelmath/
   and Foraxx Palette Utility script, copyright (C) 2024 Paul Hancock

   This program is free software: you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation, version 3 of the License.

   This program is distributed in the hope that it will be useful, but WITHOUT
   ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
   FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for
   more details.

   You should have received a copy of the GNU General Public License along with
   this program.  If not, see <http://www.gnu.org/licenses/>.
*/


#feature-id    Westwood Astro > OSCNarrowbandExtraction

#feature-info  Interactive OSC Narrowband Extraction with an in-dialog real-time \
   preview of the synthetic SII channel that updates as the SII amount slider \
   is adjusted. Optional HOO, SHO and Foraxx (2- and 3-channel) palette image \
   creation.<br/>\
   <br/>\
   Copyright &copy; 2026 Loran Hughes, WestwoodAstro.net

#feature-icon  OSCNarrowbandExtraction.xpm

#define VERSION "1.0"

#define TITLE   "OSC Narrowband Extraction "

#define PREVIEW_SIZE 360   // target max dimension of the preview rendition, px

#define MIN_K 0.0001       // minimum pixel value (floor) for generated channels

#define PREVIEW_BG 0.25    // STF target background for the live preview
#define PALETTE_BG 0.18    // STF target background for palette copies (darker)


CoreApplication.ensureMinimumVersion( 1, 9, 4 );

/*
 * OIII channel-combination modes.
 */
#define OIII_HA_CORRECTED 0   // max( 0, 0.6*(G - 0.05*Ha) + 0.4*(B - 0.02*Ha) )
#define OIII_AVERAGE      1   // ( G + B )/2
#define OIII_GREEN        2   // G
#define OIII_BLUE         3   // B

function oiiiModeName( mode )
{
   switch ( mode )
   {
   case OIII_AVERAGE: return "Average ( G + B )/2";
   case OIII_GREEN:   return "Green only";
   case OIII_BLUE:    return "Blue only";
   case OIII_HA_CORRECTED:
   default:           return "Ha-corrected ( G, B minus Ha bleed )";
   }
}

function oiiiExpression( mode )
{
   switch ( mode )
   {
   case OIII_AVERAGE: return "( $T[1] + $T[2] )/2";
   case OIII_GREEN:   return "$T[1]";
   case OIII_BLUE:    return "$T[2]";
   case OIII_HA_CORRECTED:
   default:           return "max( 0, 0.6*( $T[1] - 0.05*$T[0] ) + 0.4*( $T[2] - 0.02*$T[0] ) )";
   }
}

/*
 * SII synthesis: SII = max( 0, Ha - amount*( OIII - med(OIII) ) ).
 */
function siiExpression( amount, haId, oiiiId )
{
   var a = format( "%.6f", amount );
   return "max( 0, " + haId + " - " + a + "*( " + oiiiId + " - med( " + oiiiId + " ) ) )";
}

/*
 * Creates a new grayscale image window holding the result of a PixelMath
 * expression evaluated on the target view. The new window is returned.
 */
function extractChannel( view, expression, newId )
{
   var pm = new PixelMath;
   pm.expression          = expression;
   pm.expression1         = "";
   pm.expression2         = "";
   pm.useSingleExpression = true;
   pm.variables           = "";
   pm.use64BitWorkingImage = false;
   pm.rescale             = false;
   pm.truncate            = true;
   pm.truncateLower       = 0.0;
   pm.truncateUpper       = 1.0;
   pm.createNewImage      = true;
   pm.newImageId          = newId;
   pm.newImageWidth       = 0;
   pm.newImageHeight      = 0;
   pm.newImageColorSpace  = PixelMath.Gray;
   pm.newImageSampleFormat = PixelMath.SameAsTarget;

   pm.executeOn( view, false/*swapFile*/ );

   return ImageWindow.windowById( newId );
}

/*
 * Recomputes the SII expression into an existing view, in place.
 */
function computeSIIInto( view, haId, oiiiId, amount )
{
   var pm = new PixelMath;
   pm.expression          = siiExpression( amount, haId, oiiiId );
   pm.useSingleExpression = true;
   pm.variables           = "";
   pm.use64BitWorkingImage = false;
   pm.rescale             = false;
   pm.truncate            = true;
   pm.truncateLower       = 0.0;
   pm.truncateUpper       = 1.0;
   pm.createNewImage      = false;
   pm.executeOn( view, false/*swapFile*/ );
}

/*
 * Clamps a view's pixel values to a minimum floor, in place, so no sample is
 * less than the given value: K = max( K, floor ).
 */
function applyFloor( view, floor )
{
   var pm = new PixelMath;
   pm.expression          = "max( $T, " + format( "%.8f", floor ) + " )";
   pm.useSingleExpression = true;
   pm.variables           = "";
   pm.use64BitWorkingImage = false;
   pm.rescale             = false;
   pm.truncate            = true;
   pm.truncateLower       = 0.0;
   pm.truncateUpper       = 1.0;
   pm.createNewImage      = false;
   pm.executeOn( view, false/*swapFile*/ );
}

/*
 * Linearly fits a target view to a reference view (by id).
 */
function linearFitTo( targetView, referenceId )
{
   var lf = new LinearFit;
   lf.referenceViewId = referenceId;
   lf.rejectLow  = 0.0;
   lf.rejectHigh = 0.92;
   lf.executeOn( targetView, false/*swapFile*/ );
}

/*
 * Creates a new RGB image window from three PixelMath channel expressions
 * (R, G, B). The expression strings typically reference grayscale view ids.
 */
function combineRGB( view, exprR, exprG, exprB, newId )
{
   var pm = new PixelMath;
   pm.expression          = exprR;
   pm.expression1         = exprG;
   pm.expression2         = exprB;
   pm.expression3         = "";
   pm.useSingleExpression = false;
   pm.variables           = "";
   pm.use64BitWorkingImage = false;
   pm.rescale             = false;
   pm.truncate            = true;
   pm.truncateLower       = 0.0;
   pm.truncateUpper       = 1.0;
   pm.createNewImage      = true;
   pm.newImageId          = newId;
   pm.newImageColorSpace  = PixelMath.RGB;
   pm.newImageSampleFormat = PixelMath.SameAsTarget;
   pm.executeOn( view, false/*swapFile*/ );
   return ImageWindow.windowById( newId );
}

/*
 * Applies the Foraxx finishing adjustments to a view (curves + selective
 * saturation), ported verbatim from the Foraxx Palette Utility
 * (CurvesAdjustments1, CurvesAdjustments2, SelectiveSaturationBoost x2).
 */
function applyForaxxFinishing( view )
{
   // CurvesAdjustments1
   var c1 = new CurvesTransformation;
   c1.ct = CurvesTransformation.AkimaSubsplines;
   c1.H = [ [ 0.00000, 0.00000 ],
            [ 0.02517, 0.05952 ],
            [ 0.07323, 0.08571 ],
            [ 0.11442, 0.13810 ],
            [ 0.62014, 0.67619 ],
            [ 1.00000, 1.00000 ] ];
   c1.Ht = CurvesTransformation.AkimaSubsplines;
   c1.S = [ [ 0.00000, 0.00000 ],
            [ 0.50801, 0.61667 ],
            [ 1.00000, 1.00000 ] ];
   c1.St = CurvesTransformation.AkimaSubsplines;
   c1.executeOn( view );

   // CurvesAdjustments2
   var c2 = new CurvesTransformation;
   c2.H = [ [ 0.00000, 0.00000 ],
            [ 0.05034, 0.03571 ],
            [ 0.08238, 0.10238 ],
            [ 0.24943, 0.25000 ],
            [ 1.00000, 1.00000 ] ];
   c2.Ht = CurvesTransformation.AkimaSubsplines;
   c2.executeOn( view );

   // SelectiveSaturationBoost, applied twice
   for ( var i = 0; i < 2; ++i )
   {
      var s = new ColorSaturation;
      s.HS = [ [ 0.00000,  0.00000 ],
               [ 0.04910,  0.00909 ],
               [ 0.07235,  0.00909 ],
               [ 0.10594,  0.15455 ],
               [ 0.19380,  0.00909 ],
               [ 0.37726,  0.00000 ],
               [ 0.52972,  0.00909 ],
               [ 0.60465,  0.13636 ],
               [ 0.68475, -0.00909 ],
               [ 0.84496,  0.00000 ],
               [ 1.00000,  0.00000 ] ];
      s.HSt = ColorSaturation.AkimaSubsplines;
      s.hueShift = 0.000;
      s.executeOn( view );
   }
}

/*
 * Sets the shadows (black point) and highlights (white point) so the histogram
 * is expanded to the full [0,1] range WITHOUT clipping any data (midtones left
 * at 0.5).
 *
 * If 'combined' is true, a single black/white point (the global min/max across
 * the RGB channels) is applied to the combined RGB/K channel, which preserves
 * the color balance. Otherwise each RGB channel is set to its own min/max.
 */
function setShadowsHighlights( view, combined )
{
   var image = view.image;
   var n = Math.min( 3, image.numberOfChannels );
   var H = [ [ 0, 0.5, 1, 0, 1 ],   // R
             [ 0, 0.5, 1, 0, 1 ],   // G
             [ 0, 0.5, 1, 0, 1 ],   // B
             [ 0, 0.5, 1, 0, 1 ],   // RGB/K
             [ 0, 0.5, 1, 0, 1 ] ]; // Alpha
   if ( combined )
   {
      // Color-preserving: one black/white point on the combined RGB/K channel.
      var lo = image.minimum( new Rect(), 0, n - 1 );
      var hi = image.maximum( new Rect(), 0, n - 1 );
      if ( hi - lo > 1.0e-6 )
         H[3] = [ lo, 0.5, hi, 0, 1 ];
   }
   else
   {
      for ( var c = 0; c < n; ++c )
      {
         var loc = image.minimum( new Rect(), c, c );
         var hic = image.maximum( new Rect(), c, c );
         if ( hic - loc > 1.0e-6 )
            H[c] = [ loc, 0.5, hic, 0, 1 ]; // c0 = min, c1 = max -> no clipping
      }
   }
   var ht = new HistogramTransformation;
   ht.H = H;
   ht.executeOn( view, false/*swapFile*/ );
}

/*
 * Creates a new (hidden) image window holding a copy of the given source
 * window's image, optionally integer-downsampled by |zoomFactor| (a negative
 * integer; 0 or -1 means no downsampling).
 */
function makeDownsampledCopy( srcWindow, newId, zoomFactor )
{
   var img = srcWindow.mainView.image;
   var w = new ImageWindow( img.width, img.height, img.numberOfChannels,
                            srcWindow.bitsPerSample, srcWindow.isFloatSample,
                            false/*color*/, newId );
   w.mainView.beginProcess( UndoFlag.NoSwapFile );
   w.mainView.image.apply( img );
   w.mainView.endProcess();

   if ( zoomFactor < -1 )
   {
      var ir = new IntegerResample;
      ir.zoomFactor = zoomFactor;
      ir.downsamplingMode = IntegerResample.Average;
      ir.executeOn( w.mainView, false/*swapFile*/ );
   }
   return w;
}

/*
 * Applies an STF-style automatic stretch to a view, in place (destructive).
 * Used on disposable preview/palette copies. A lower targetBackground yields a
 * darker background.
 */
function autoStretchView( view, targetBackground )
{
   var shadowsClipping = -2.80;
   if ( targetBackground === undefined )
      targetBackground = 0.25;

   var image  = view.image;
   var median = image.median();
   var mad    = image.MAD() * 1.4826;
   if ( mad == 0 )
      mad = 1.0;

   var c0 = Math.range( median + shadowsClipping * mad, 0.0, 1.0 );
   var m  = Math.mtf( targetBackground, median - c0 );

   var ht = new HistogramTransformation;
   ht.H = [ [ 0,  0.5, 1, 0, 1 ],
            [ 0,  0.5, 1, 0, 1 ],
            [ 0,  0.5, 1, 0, 1 ],
            [ c0, m,   1, 0, 1 ],
            [ 0,  0.5, 1, 0, 1 ] ];
   ht.executeOn( view, false/*swapFile*/ );
}

/*
 * Forces a linear (identity) screen transfer function on a view, so a linear
 * image is also displayed linearly (not auto-stretched on screen). This does
 * not modify pixel data.
 */
function resetLinearSTF( view )
{
   var stf = new ScreenTransferFunction;
   stf.STF = [ [ 0, 1, 0.5, 0, 1 ],
               [ 0, 1, 0.5, 0, 1 ],
               [ 0, 1, 0.5, 0, 1 ],
               [ 0, 1, 0.5, 0, 1 ] ];
   stf.executeOn( view );
}

/*
 * Builds a valid, unique view identifier from a base name.
 */
function uniqueViewId( baseId )
{
   var id = baseId.replace( /[^0-9A-Za-z_]/g, "_" );
   if ( id.length == 0 || (id[0] >= '0' && id[0] <= '9') )
      id = "_" + id;
   var candidate = id;
   for ( var i = 1; ; ++i )
   {
      var w = ImageWindow.windowById( candidate );
      if ( w === null || w.isNull )
         break;
      candidate = id + "_" + i;
   }
   return candidate;
}

/*
 * Script parameters.
 */
function OSCNBData()
{
   var window = ImageWindow.activeWindow;
   this.targetView  = window.isNull ? null : window.currentView;
   this.extractHa   = true;
   this.extractOIII = true;
   this.oiiiMode    = OIII_HA_CORRECTED;
   this.extractSII  = false;
   this.siiAmount   = 0.50;
   this.createHOO          = false;
   this.createHaOIIIForaxx = false;
   this.createSHO          = false;
   this.createForaxx       = false;
}

var data = new OSCNBData;

var OSCNBPreviewDialog = class extends Dialog
{
   constructor()
   {
      super();

      // Interactive state.
      this.haWindow      = null;
      this.oiiiWindow    = null;
      this.siiWindow     = null;
      this.smallHa       = null;
      this.smallOiii     = null;
      this.smallSII      = null;
      this.previewBitmap = null;
      this.channelsDone  = false;
      this.siiDone       = false;

      var labelWidth1 = this.font.width( "OIII combination:" + 'T' );

      //

      this.helpLabel = new Label( this );
      this.helpLabel.frameStyle = FrameStyle.Box;
      this.helpLabel.margin = 4;
      this.helpLabel.wordWrapping = true;
      this.helpLabel.useRichText = true;
      this.helpLabel.text =
         "<p><b>" + TITLE + " v" + VERSION + "</b></p>"
         + "<p>Click <b>Extract Ha/OIII</b> to create the linear Ha and OIII "
         + "images (OIII fitted to Ha). Check <b>Synthetic SII</b> to show a "
         + "live, screen-stretched preview (right) that updates as you drag the "
         + "<b>SII amount</b> slider. Click <b>Create SII</b> to generate the "
         + "(linear) SII channel, fitted to Ha. The preview stretch is display "
         + "only; all generated channels are linear. Generated palettes are "
         + "non-linear.</p>"
         + "<p>Use starless images for best results.</p>"
         + "<p>&copy; 2026 Loran Hughes, WestwoodAstro.net</p>";

      // Target image
      this.targetImage_Label = new Label( this );
      this.targetImage_Label.minWidth = labelWidth1;
      this.targetImage_Label.text = "Target image:";
      this.targetImage_Label.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;

      this.targetImage_ViewList = new ViewList( this );
      this.targetImage_ViewList.scaledMinWidth = 240;
      this.targetImage_ViewList.getAll();
      if ( data.targetView !== null )
         this.targetImage_ViewList.currentView = data.targetView;
      this.targetImage_ViewList.toolTip = "Select the OSC dual-band RGB image to extract from.";
      this.targetImage_ViewList.onViewSelected = ( view ) =>
      {
         data.targetView = view;
      };

      this.targetImage_Sizer = new HorizontalSizer;
      this.targetImage_Sizer.spacing = 4;
      this.targetImage_Sizer.add( this.targetImage_Label );
      this.targetImage_Sizer.add( this.targetImage_ViewList, 100 );

      // Channels to extract
      this.extractHa_CheckBox = new CheckBox( this );
      this.extractHa_CheckBox.text = "Extract Ha  ( R )";
      this.extractHa_CheckBox.checked = data.extractHa;
      this.extractHa_CheckBox.toolTip =
         "<p>Create a grayscale Ha image from the red channel of the target image.</p>";
      this.extractHa_CheckBox.onCheck = ( checked ) =>
      {
         data.extractHa = checked;
      };

      this.extractOIII_CheckBox = new CheckBox( this );
      this.extractOIII_CheckBox.text = "Extract OIII  ( G, B )";
      this.extractOIII_CheckBox.checked = data.extractOIII;
      this.extractOIII_CheckBox.toolTip =
         "<p>Create a grayscale OIII image from the green and blue channels of "
         + "the target image.</p>";
      this.extractOIII_CheckBox.onCheck = ( checked ) =>
      {
         data.extractOIII = checked;
      };

      this.extractSII_CheckBox = new CheckBox( this );
      this.extractSII_CheckBox.text = "Synthetic SII";
      this.extractSII_CheckBox.checked = data.extractSII;
      this.extractSII_CheckBox.toolTip =
         "<p>Enable the interactive synthetic SII preview. Requires Ha and OIII.</p>";
      this.extractSII_CheckBox.onCheck = ( checked ) =>
      {
         data.extractSII = checked;
         if ( !checked )
         {
            // SHO/Foraxx need SII; clear them when their options are hidden.
            data.createSHO = false;
            data.createForaxx = false;
            this.sho_CheckBox.checked = false;
            this.foraxx_CheckBox.checked = false;
         }
         this.showPreviewPanel( checked );
         if ( this.channelsDone )
         {
            if ( checked )
               this.openPreview();
            else
               this.closePreview();
         }
         this.updateControls();
      };

      this.channels_Sizer = new HorizontalSizer;
      this.channels_Sizer.spacing = 12;
      this.channels_Sizer.add( this.extractHa_CheckBox );
      this.channels_Sizer.add( this.extractOIII_CheckBox );
      this.channels_Sizer.add( this.extractSII_CheckBox );
      this.channels_Sizer.addStretch();

      // OIII combination
      this.oiiiMode_Label = new Label( this );
      this.oiiiMode_Label.minWidth = labelWidth1;
      this.oiiiMode_Label.text = "OIII combination:";
      this.oiiiMode_Label.textAlignment = TextAlignment.Right|TextAlignment.VertCenter;

      this.oiiiMode_ComboBox = new ComboBox( this );
      this.oiiiMode_ComboBox.addItem( oiiiModeName( OIII_HA_CORRECTED ) );
      this.oiiiMode_ComboBox.addItem( oiiiModeName( OIII_AVERAGE ) );
      this.oiiiMode_ComboBox.addItem( oiiiModeName( OIII_GREEN ) );
      this.oiiiMode_ComboBox.addItem( oiiiModeName( OIII_BLUE ) );
      this.oiiiMode_ComboBox.currentItem = data.oiiiMode;
      this.oiiiMode_ComboBox.toolTip = this.oiiiMode_Label.toolTip =
         "<p>How to combine the green and blue channels to build the OIII image.</p>";
      this.oiiiMode_ComboBox.onItemSelected = ( index ) =>
      {
         data.oiiiMode = index;
      };

      this.oiiiMode_Sizer = new HorizontalSizer;
      this.oiiiMode_Sizer.spacing = 4;
      this.oiiiMode_Sizer.add( this.oiiiMode_Label );
      this.oiiiMode_Sizer.add( this.oiiiMode_ComboBox );
      this.oiiiMode_Sizer.addStretch();

      // Synthetic SII coefficient (live)
      this.siiAmount_NC = new NumericControl( this );
      this.siiAmount_NC.label.text = "SII amount (k):";
      this.siiAmount_NC.label.minWidth = labelWidth1;
      this.siiAmount_NC.setRange( 0.0, 1.0 );
      this.siiAmount_NC.slider.setRange( 0, 100 );
      this.siiAmount_NC.slider.scaledMinWidth = 200;
      this.siiAmount_NC.setPrecision( 2 );
      this.siiAmount_NC.setValue( data.siiAmount );
      this.siiAmount_NC.toolTip =
         "<p>Residual coefficient <i>k</i>: SII = max( 0, Ha &minus; "
         + "k&times;(OIII &minus; med(OIII)) ). Updates the preview live.</p>";
      this.siiAmount_NC.onValueUpdated = ( value ) =>
      {
         data.siiAmount = value;
         this.updatePreview();
      };

      this.par_GroupBox = new GroupBox( this );
      this.par_GroupBox.title = "Extraction Parameters";
      this.par_GroupBox.sizer = new VerticalSizer;
      this.par_GroupBox.sizer.margin = 6;
      this.par_GroupBox.sizer.spacing = 4;
      this.par_GroupBox.sizer.add( this.channels_Sizer );
      this.par_GroupBox.sizer.add( this.oiiiMode_Sizer );
      this.par_GroupBox.sizer.add( this.siiAmount_NC );

      // Palette options. HOO is always available (Ha/OIII only); SHO and Foraxx
      // require the synthetic SII and are shown only when it is checked.
      this.hoo_CheckBox = new CheckBox( this );
      this.hoo_CheckBox.text = "Create HOO Palette Image";
      this.hoo_CheckBox.checked = data.createHOO;
      this.hoo_CheckBox.toolTip =
         "<p>Combine statistically-stretched copies of Ha and OIII into an "
         + "HOO bicolor palette image: R = Ha, G = OIII, B = OIII.</p>";
      this.hoo_CheckBox.onCheck = ( checked ) =>
      {
         data.createHOO = checked;
      };

      this.haOIIIForaxx_CheckBox = new CheckBox( this );
      this.haOIIIForaxx_CheckBox.text = "Create 2-Channel (Ha-OIII) Foraxx Palette Image";
      this.haOIIIForaxx_CheckBox.checked = data.createHaOIIIForaxx;
      this.haOIIIForaxx_CheckBox.toolTip =
         "<p>Combine statistically-stretched copies of Ha and OIII into a "
         + "two-channel Foraxx dynamic palette image (no SII).</p>";
      this.haOIIIForaxx_CheckBox.onCheck = ( checked ) =>
      {
         data.createHaOIIIForaxx = checked;
      };

      this.sho_CheckBox = new CheckBox( this );
      this.sho_CheckBox.text = "Create SHO Palette Image";
      this.sho_CheckBox.checked = data.createSHO;
      this.sho_CheckBox.toolTip =
         "<p>Combine a statistically-stretched copy of each channel into an "
         + "SHO (Hubble) palette image: R = SII, G = Ha, B = OIII.</p>";
      this.sho_CheckBox.onCheck = ( checked ) =>
      {
         data.createSHO = checked;
      };

      this.foraxx_CheckBox = new CheckBox( this );
      this.foraxx_CheckBox.text = "Create 3-Channel (Ha-OIII-SII) Foraxx Palette Image";
      this.foraxx_CheckBox.toolTip =
         "<p>Combine statistically-stretched copies of Ha, OIII and SII into a "
         + "three-channel Foraxx dynamic palette image.</p>";
      this.foraxx_CheckBox.checked = data.createForaxx;
      this.foraxx_CheckBox.onCheck = ( checked ) =>
      {
         data.createForaxx = checked;
      };

      this.palette_GroupBox = new GroupBox( this );
      this.palette_GroupBox.title = "Palettes (optional)";
      this.palette_GroupBox.sizer = new VerticalSizer;
      this.palette_GroupBox.sizer.margin = 6;
      this.palette_GroupBox.sizer.spacing = 4;
      this.palette_GroupBox.sizer.add( this.hoo_CheckBox );
      this.palette_GroupBox.sizer.add( this.haOIIIForaxx_CheckBox );
      this.palette_GroupBox.sizer.add( this.sho_CheckBox );
      this.palette_GroupBox.sizer.add( this.foraxx_CheckBox );

      // Left column (controls)
      // Step-by-step instructions (shown only when Synthetic SII is checked).
      this.instructions_Label = new Label( this );
      this.instructions_Label.frameStyle = FrameStyle.Box;
      this.instructions_Label.margin = 4;
      this.instructions_Label.useRichText = true;
      this.instructions_Label.text =
         "<p><b>Synthetic SII steps:</b></p>"
         + "<p>1. Click <b>Extract Ha/OIII</b><br/>"
         + "2. Adjust <b>SII amount</b> as desired<br/>"
         + "3. Click <b>Create SII</b></p>"
         + "<p><b>NOTE:</b> Optional <b>Palettes</b> are generated automatically at Step 3</p>";

      this.left_Sizer = new VerticalSizer;
      this.left_Sizer.spacing = 6;
      this.left_Sizer.add( this.targetImage_Sizer );
      this.left_Sizer.add( this.par_GroupBox );
      this.left_Sizer.add( this.palette_GroupBox );
      this.left_Sizer.add( this.instructions_Label );
      this.left_Sizer.addStretch();

      // Preview panel (right)
      this.previewControl = new Control( this );
      this.previewControl.setScaledFixedSize( PREVIEW_SIZE + 16, PREVIEW_SIZE + 16 );
      this.previewControl.toolTip = "<p>Screen-stretched, downsampled preview of the synthetic SII channel.</p>";
      this.previewControl.onPaint = ( x0, y0, x1, y1 ) =>
      {
         var g = new Graphics( this.previewControl );
         g.brush = new Brush( 0xff101010 );
         g.pen = new Pen( 0xff101010 );
         g.fillRect( 0, 0, this.previewControl.width, this.previewControl.height );
         if ( this.previewBitmap !== null )
         {
            var px = Math.round( (this.previewControl.width  - this.previewBitmap.width ) / 2 );
            var py = Math.round( (this.previewControl.height - this.previewBitmap.height) / 2 );
            g.drawBitmap( px, py, this.previewBitmap );
         }
         g.end();
      };

      this.preview_GroupBox = new GroupBox( this );
      this.preview_GroupBox.title = "Synthetic SII Preview (screen-stretched)";
      this.preview_GroupBox.sizer = new VerticalSizer;
      this.preview_GroupBox.sizer.margin = 6;
      this.preview_GroupBox.sizer.add( this.previewControl );

      // Controls + preview, side by side
      this.content_Sizer = new HorizontalSizer;
      this.content_Sizer.spacing = 8;
      this.content_Sizer.add( this.left_Sizer, 100 );
      this.content_Sizer.add( this.preview_GroupBox );

      // Buttons
      this.extract_Button = new PushButton( this );
      this.extract_Button.text = "Extract Ha/OIII";
      this.extract_Button.icon = this.scaledResource( ":/icons/execute.png" );
      this.extract_Button.toolTip = "<p>Create the Ha and OIII channels (and open the SII preview).</p>";
      this.extract_Button.onClick = () =>
      {
         this.onExtract();
      };

      this.createSII_Button = new PushButton( this );
      this.createSII_Button.text = "Create SII";
      this.createSII_Button.icon = this.scaledResource( ":/icons/ok.png" );
      this.createSII_Button.toolTip = "<p>Generate the full-resolution SII channel at the current amount.</p>";
      this.createSII_Button.onClick = () =>
      {
         if ( this.finalizeSII() )
         {
            // SII created — dispose the preview and close the dialog.
            this.closePreview();
            this.ok();
         }
         else
            this.updateControls();
      };

      this.close_Button = new PushButton( this );
      this.close_Button.text = "Close";
      this.close_Button.icon = this.scaledResource( ":/icons/close.png" );
      this.close_Button.onClick = () =>
      {
         this.closePreview();
         this.ok();
      };

      this.buttons_Sizer = new HorizontalSizer;
      this.buttons_Sizer.spacing = 4;
      this.buttons_Sizer.add( this.extract_Button );
      this.buttons_Sizer.add( this.createSII_Button );
      this.buttons_Sizer.addStretch();
      this.buttons_Sizer.add( this.close_Button );

      this.sizer = new VerticalSizer;
      this.sizer.margin = 8;
      this.sizer.spacing = 6;
      this.sizer.add( this.helpLabel );
      this.sizer.addSpacing( 4 );
      this.sizer.add( this.content_Sizer );
      this.sizer.addSpacing( 4 );
      this.sizer.add( this.buttons_Sizer );

      // The preview panel and instructions are hidden until SII is checked. The
      // Palettes block is always visible; SHO and Foraxx options (which need SII)
      // are shown only when Synthetic SII is checked. HOO is always available.
      this.preview_GroupBox.visible   = data.extractSII;
      this.instructions_Label.visible = data.extractSII;
      this.sho_CheckBox.visible       = data.extractSII;
      this.foraxx_CheckBox.visible    = data.extractSII;

      this.windowTitle = TITLE;
      this.adjustToContents();
      this.setFixedSize();

      this.updateControls();
   }

   // --- Interactive logic -------------------------------------------------

   showPreviewPanel( show )
   {
      if ( this.preview_GroupBox.visible === show )
         return;
      this.preview_GroupBox.visible   = show;
      this.instructions_Label.visible = show;
      this.sho_CheckBox.visible       = show;
      this.foraxx_CheckBox.visible    = show;
      // Resize the (otherwise fixed-size) dialog to fit the new layout.
      this.setVariableSize();
      this.adjustToContents();
      this.setFixedSize();
   }

   onExtract()
   {
      if ( this.channelsDone )
         return;

      if ( data.targetView === null || data.targetView.isNull )
      {
         ( new MessageBox( "Please select a target view.",
                           TITLE, StdIcon.Error, StdButton.Ok ) ).execute();
         return;
      }
      if ( data.targetView.image.numberOfChannels < 3 )
      {
         ( new MessageBox( "The target image must be an RGB color image (at least 3 channels).",
                           TITLE, StdIcon.Error, StdButton.Ok ) ).execute();
         return;
      }
      if ( !data.extractHa && !data.extractOIII && !data.extractSII
           && !data.createHOO && !data.createHaOIIIForaxx
           && !data.createSHO && !data.createForaxx )
      {
         ( new MessageBox( "Select at least one of Ha, OIII, synthetic SII, or a palette.",
                           TITLE, StdIcon.Error, StdButton.Ok ) ).execute();
         return;
      }

      this.ensureChannels();

      if ( data.extractSII )
      {
         // Keep the dialog open for the SII preview / Create SII step.
         this.openPreview();
         this.updateControls();
      }
      else
      {
         // No SII: build any requested palette (HOO), then close.
         this.buildPalettes();
         this.disposeUnkeptChannels();
         this.ok();
      }
   }

   disposeUnkeptChannels()
   {
      if ( !data.extractHa && this.haWindow !== null && !this.haWindow.isNull )
      {
         this.haWindow.forceClose();
         this.haWindow = null;
      }
      if ( !data.extractOIII && this.oiiiWindow !== null && !this.oiiiWindow.isNull )
      {
         this.oiiiWindow.forceClose();
         this.oiiiWindow = null;
      }
   }

   ensureChannels()
   {
      var view = data.targetView;
      var baseId = view.id;

      // SII and the palettes all need both Ha and OIII; generate them whenever
      // SII or any palette is requested, even if the user did not ask to keep
      // the mono channels.
      var anyPalette = data.createHOO || data.createHaOIIIForaxx
                       || data.createSHO || data.createForaxx;
      var needHa   = data.extractHa   || data.extractSII || anyPalette;
      var needOIII = data.extractOIII || data.extractSII || anyPalette;

      if ( needHa )
         this.haWindow = extractChannel( view, "$T[0]", uniqueViewId( baseId + "_Ha" ) );
      if ( needOIII )
         this.oiiiWindow = extractChannel( view, oiiiExpression( data.oiiiMode ),
                                           uniqueViewId( baseId + "_OIII" ) );

      // LinearFit OIII to Ha (both stay linear).
      if ( this.haWindow !== null && this.oiiiWindow !== null )
      {
         linearFitTo( this.oiiiWindow.mainView, this.haWindow.mainView.id );
         console.writeln( "<end><cbr>* OIII linearly fitted to " + this.haWindow.mainView.id );
      }

      // Clamp each channel to the minimum pixel floor.
      if ( this.haWindow !== null )
         applyFloor( this.haWindow.mainView, MIN_K );
      if ( this.oiiiWindow !== null )
         applyFloor( this.oiiiWindow.mainView, MIN_K );

      if ( data.extractHa && this.haWindow !== null )
      {
         resetLinearSTF( this.haWindow.mainView );
         this.haWindow.show();
         this.haWindow.zoomToOptimalFit();
         console.writeln( "<end><cbr>* Ha image created (linear): " + this.haWindow.mainView.id );
      }
      if ( data.extractOIII && this.oiiiWindow !== null )
      {
         resetLinearSTF( this.oiiiWindow.mainView );
         this.oiiiWindow.show();
         this.oiiiWindow.zoomToOptimalFit();
         console.writeln( "<end><cbr>* OIII image created (linear): " + this.oiiiWindow.mainView.id );
      }

      this.channelsDone = true;
   }

   openPreview()
   {
      if ( this.smallSII !== null )
         return; // already open
      if ( this.haWindow === null || this.oiiiWindow === null )
         return;

      var baseId = data.targetView.id;

      // Integer-downsample factor so the longest side is about PREVIEW_SIZE px.
      var maxDim = Math.max( this.haWindow.mainView.image.width,
                             this.haWindow.mainView.image.height );
      var n = Math.max( 1, Math.round( maxDim / PREVIEW_SIZE ) );
      var zf = (n > 1) ? -n : 0;

      this.smallHa   = makeDownsampledCopy( this.haWindow,   uniqueViewId( baseId + "_Ha_prev" ),   zf );
      this.smallOiii = makeDownsampledCopy( this.oiiiWindow, uniqueViewId( baseId + "_OIII_prev" ), zf );
      this.smallSII  = makeDownsampledCopy( this.smallHa,    uniqueViewId( baseId + "_SII_prev" ),  0 );

      this.updatePreview();
   }

   updatePreview()
   {
      if ( this.smallSII === null )
         return;
      computeSIIInto( this.smallSII.mainView,
                      this.smallHa.mainView.id, this.smallOiii.mainView.id, data.siiAmount );
      autoStretchView( this.smallSII.mainView, PREVIEW_BG ); // destructive, on the small copy
      this.previewBitmap = this.smallSII.mainView.image.render();
      this.previewControl.repaint();
   }

   closePreview()
   {
      if ( this.smallSII   !== null && !this.smallSII.isNull )   this.smallSII.forceClose();
      if ( this.smallHa    !== null && !this.smallHa.isNull )    this.smallHa.forceClose();
      if ( this.smallOiii  !== null && !this.smallOiii.isNull )  this.smallOiii.forceClose();
      this.smallSII = this.smallHa = this.smallOiii = null;
      this.previewBitmap = null;
      this.previewControl.repaint();
   }

   finalizeSII()
   {
      if ( !this.channelsDone || this.haWindow === null || this.oiiiWindow === null )
         return false;

      // Generate the full-resolution SII at the current amount, then fit to Ha.
      var expr = siiExpression( data.siiAmount,
                                this.haWindow.mainView.id, this.oiiiWindow.mainView.id );
      var sii = extractChannel( data.targetView, expr,
                                uniqueViewId( data.targetView.id + "_Synth_SII" ) );
      linearFitTo( sii.mainView, this.haWindow.mainView.id );
      applyFloor( sii.mainView, MIN_K );
      resetLinearSTF( sii.mainView );
      sii.show();
      sii.zoomToOptimalFit();
      this.siiWindow = sii;
      console.writeln( "<end><cbr>* Synthetic SII image created: " + sii.mainView.id
                       + format( "  [k = %.2f]", data.siiAmount ) );

      this.buildPalettes();
      this.disposeUnkeptChannels();

      this.siiDone = true;
      return true;
   }

   buildPalettes()
   {
      // SHO and Foraxx require the synthetic SII; HOO needs only Ha and OIII.
      var haveSII   = this.siiWindow !== null && !this.siiWindow.isNull;
      var wantSII   = ( data.createSHO || data.createForaxx ) && haveSII;
      var wantAny   = data.createHOO || data.createHaOIIIForaxx || wantSII;
      if ( !wantAny )
         return;
      if ( this.haWindow === null || this.oiiiWindow === null )
         return;

      var baseId = data.targetView.id;

      // Temporary, statistically-stretched copies of each channel. The original
      // Ha/OIII/SII windows are left linear and untouched.
      var haC   = makeDownsampledCopy( this.haWindow,   uniqueViewId( baseId + "_Ha_tmp" ),   0 );
      var oiiiC = makeDownsampledCopy( this.oiiiWindow, uniqueViewId( baseId + "_OIII_tmp" ), 0 );
      autoStretchView( haC.mainView,   PALETTE_BG );
      autoStretchView( oiiiC.mainView, PALETTE_BG );

      var H = haC.mainView.id, O = oiiiC.mainView.id;

      var siiC = null, S = null;
      if ( wantSII )
      {
         siiC = makeDownsampledCopy( this.siiWindow, uniqueViewId( baseId + "_SII_tmp" ), 0 );
         autoStretchView( siiC.mainView, PALETTE_BG );
         S = siiC.mainView.id;
      }

      // HOO bicolor palette: R = Ha, G = OIII, B = OIII.
      if ( data.createHOO )
      {
         var hoo = combineRGB( data.targetView, H, O, O, uniqueViewId( baseId + "_HOO" ) );
         if ( hoo !== null && !hoo.isNull )
         {
            setShadowsHighlights( hoo.mainView );
            hoo.show();
            hoo.zoomToOptimalFit();
            console.writeln( "<end><cbr>* HOO palette created: " + hoo.mainView.id );
         }
      }

      // Two-channel Ha-OIII Foraxx palette (no SII), per the Foraxx Palette
      // Utility twoChannels path:
      //   hoString = (Ha*OIII)^~(Ha*OIII)
      //   R = Ha
      //   G = (hoString)*Ha + ~(hoString)*OIII
      //   B = OIII
      if ( data.createHaOIIIForaxx )
      {
         var hoStr2 = "(" + H + "*" + O + ")^~(" + H + "*" + O + ")";
         var f2G = "(" + hoStr2 + ")*" + H + "+ ~(" + hoStr2 + ")*" + O;
         var fx2 = combineRGB( data.targetView, H, f2G, O, uniqueViewId( baseId + "_Foraxx_HaOIII" ) );
         if ( fx2 !== null && !fx2.isNull )
         {
            applyForaxxFinishing( fx2.mainView );
            setShadowsHighlights( fx2.mainView, true/*combined: preserve color*/ );
            fx2.show();
            fx2.zoomToOptimalFit();
            console.writeln( "<end><cbr>* Ha-OIII Foraxx palette created: " + fx2.mainView.id );
         }
      }

      // SHO (Hubble) palette: R = SII, G = Ha, B = OIII.
      if ( data.createSHO && S !== null )
      {
         var sho = combineRGB( data.targetView, S, H, O, uniqueViewId( baseId + "_SHO" ) );
         if ( sho !== null && !sho.isNull )
         {
            setShadowsHighlights( sho.mainView );
            sho.show();
            sho.zoomToOptimalFit();
            console.writeln( "<end><cbr>* SHO palette created: " + sho.mainView.id );
         }
      }

      // Foraxx three-channel dynamic palette (from Ha, OIII and SII), per the
      // Foraxx Palette Utility ImageConstructor:
      //   oString  = OIII^~OIII
      //   hoString = (Ha*OIII)^~(Ha*OIII)
      //   R = (oString)*SII  + ~(oString)*Ha
      //   G = (hoString)*Ha  + ~(hoString)*OIII
      //   B = OIII
      if ( data.createForaxx && S !== null )
      {
         var oStr  = O + "^~" + O;
         var hoStr = "(" + H + "*" + O + ")^~(" + H + "*" + O + ")";
         var fR = "(" + oStr  + ")*" + S + "+ ~(" + oStr  + ")*" + H;
         var fG = "(" + hoStr + ")*" + H + "+ ~(" + hoStr + ")*" + O;
         var fB = O;
         var fx = combineRGB( data.targetView, fR, fG, fB, uniqueViewId( baseId + "_Foraxx" ) );
         if ( fx !== null && !fx.isNull )
         {
            applyForaxxFinishing( fx.mainView );
            setShadowsHighlights( fx.mainView, true/*combined: preserve color*/ );
            fx.show();
            fx.zoomToOptimalFit();
            console.writeln( "<end><cbr>* Foraxx palette created: " + fx.mainView.id );
         }
      }

      // Delete the temporary channel copies.
      haC.forceClose();
      oiiiC.forceClose();
      if ( siiC !== null )
         siiC.forceClose();
   }

   updateControls()
   {
      var previewOpen = this.smallSII !== null;
      this.extract_Button.enabled       = !this.channelsDone;
      this.targetImage_ViewList.enabled = !this.channelsDone;
      this.oiiiMode_ComboBox.enabled    = !this.channelsDone;
      this.extractHa_CheckBox.enabled   = !this.channelsDone;
      this.extractOIII_CheckBox.enabled = !this.channelsDone;
      this.siiAmount_NC.enabled         = previewOpen;
      this.createSII_Button.enabled     = previewOpen;
   }
};

/*
 * Script entry point.
 */
function main()
{
   console.hide();

   if ( data.targetView === null || data.targetView.isNull )
   {
      ( new MessageBox( "There is no active image window!",
                        TITLE, StdIcon.Error, StdButton.Ok ) ).execute();
      return;
   }

   console.show();
   var dialog = new OSCNBPreviewDialog();
   dialog.execute();
}

main();
